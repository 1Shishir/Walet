﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Walet
{
	
	public partial class MainForm : Form
	{   double day=30;
		double rl=0;
		double lim=0;
		double bud=0;
		double a1=0,a2=0,a3=0,a4=0,a5=0,a6=0,a7=0,a8=0,a9=0,a10=0,a11=0,a12=0;
		double b1=0,b2=0,b3=0,b4=0,b5=0,b6=0,b7=0,b8=0,b9=0,b10=0,b11=0,b12=0;
		double c1=0,c2=0,c3=0,c4=0,c5=0,c6=0,c7=0,c8=0,c9=0,c10=0,c11=0,c12=0;
		double sum=0;
		double sum1=0;
		double sum2=0;
		double r=0;
		double s=0;
		//double y=21;
		//double g=71;
		int f=0;
		int i=1;
		int tr1=10;
		string account_name="New Acc1";
		string password = null;
		public MainForm()
		{
			InitializeComponent();
			//Date
			DateTime d =new DateTime();
			d=DateTime.Now;
		    Text="Walet	"+"                                                                                                                                       "+ d.ToString("dd.MM.yyyy");
		   
		   // hoMe();
		 
		}
		
	
		
		//Exit
		void ExitToolStripMenuItemClick(object sender, EventArgs e)
		{
			this.Close();
		}
		//setting
		void PictureBox1Click(object sender, EventArgs e)
		{ 
			MessageBox.Show("Not available at this Moment");
		//	label2.Visible=true;
			//pictureBox4.Visible=true;
		}
	//calender
	
		
		
		//Dark mode switch on 
	
/*
		void PictureBox3Click(object sender, EventArgs e)
		{
	     pictureBox4.Visible=true;
	     pictureBox3.Visible=false;
		 darkMode();
		}
		//Darkmode switch off
		void PictureBox4Click(object sender, EventArgs e)
		{
			pictureBox3.Visible=true;
			pictureBox4.Visible=false;
			
			
		}
		//dark mode
		void darkMode()
		{
			MessageBox.Show("Dark mode Enabled");
		}
		*/
		
		//disable
	     void disable()
		{
		pictureBox1.Enabled=false;
	    menuStrip1.Enabled=false;
		}
	    //1st page
	 /*   void hoMe()
	    {
	    this.BackColor=Color.LightSeaGreen;
	    menuStrip1.Visible=false;	
	    pictureBox2.Visible=false;
	    pictureBox1.Visible=false;}
	  */  
	    
	  //Enable
	  void enable()
	  {
	  pictureBox1.Enabled=true;
	  menuStrip1.Enabled=true;
	  }
	
	  void mobileView()
	  {

	  scrreen.Visible=true;
	  pictureBox10.Visible=true;                                          
	  }
	  void allRaw()
	  {
	  //pictureBox6.Text="0";
	//  pictureBox7.Text="";
	  
	  
	  }
	    //add button
		void PictureBox2Click(object sender, EventArgs e)
		{	
			allRaw();
  			cL();
			panel1.Visible=true;
			disable();
			pictureBox2.Visible=false;                                          
			label1.BackColor=Color.WhiteSmoke;
			
		}
		
		
		
		//back button panel1
		void PictureBox3Click(object sender, EventArgs e)
		{
			label1.BackColor=Color.LightSeaGreen;
			enable();
			panel1.Visible=false;
			pictureBox2.Visible=true;
			
		}
		// ok button panel1
		void PictureBox4Click(object sender, EventArgs e)
		{
			if(s==1){
				
				
			
			password=textBox4.Text;
		
		//	    //(f==0)
			//{
			   if(i==1)
			   {monthCalendar1.Visible=true;}
		    mobileView();
			enable();
			panel3.Visible=true;
			panel2.Visible=true;
			//                                          pictureBox8.Visible=true;
		//                                          	pictureBox9.Visible=true;
			panel1.Visible=false;
		    pictureBox7.Visible=true;
			pictureBox2.Visible=false;                                          
			label1.BackColor=Color.WhiteSmoke;
			//}
			//else if(password==null)
			{
			//                          incomplite
			}
			}
			else{
			MessageBox.Show("Please set a Budget");}
		}
		
	
		//account_name
		void TextBox1TextChanged(object sender, EventArgs e)
		{
			account_name = textBox1.Text;
			
		}
		// trace bar
		void TrackBar1Scroll(object sender, EventArgs e)
		{
		tr1 = trackBar1.Value;
		if(tr1<5)
		{
		textBox3.Text="Daily";
		day=1;
		label16.Text=Convert.ToString(bud/day);
		}
		else if(tr1==5)
		{
		textBox3.Text="Weekly";
		day=7;
		label16.Text=Convert.ToString(bud/day);
		}
		else if(tr1>5)
		{
		textBox3.Text="Monthly";
		day=30;
		label16.Text=Convert.ToString(bud/day);
		}
		else
		{
		textBox3.Text="Monthly";
		day=30;
		}
		}
		
		
		//red switch
		void PictureBox5Click(object sender, EventArgs e)
		{
          pictureBox5.Visible=false;
          pictureBox6.Visible=true;	
		  textBox4.Visible=false;
		  label7.Visible=false;
		  f=0;
		}
		//green switch
		void PictureBox6Click(object sender, EventArgs e)
		{
		  pictureBox6.Visible=false;
		  pictureBox5.Visible=true;
		  textBox4.Visible=true;
		  label7.Visible=true;
		 f=1;
		}
		

		
		//add new raw
		void PictureBox11Click(object sender, EventArgs e)
		{
			if(textBox11.Visible == false)      //2
			{
			textBox11.Visible=true;
			textBox12.Visible=true;
			textBox13.Visible=true;
			textBox14.Visible=true;
			textBox15.Visible=true;
			textBox16.Visible=true;
			}
			
			else if(textBox17.Visible == false)    //3
			{
			textBox17.Visible=true;
			textBox18.Visible=true;
			textBox19.Visible=true;
			textBox20.Visible=true;
			textBox21.Visible=true;
			textBox22.Visible=true;
			}
			
			else if(textBox23.Visible == false)   //4
			{
			textBox23.Visible=true;
			textBox24.Visible=true;
			textBox25.Visible=true;
			textBox26.Visible=true;
			textBox27.Visible=true;
			textBox28.Visible=true;
			}
			
			else if(textBox29.Visible == false)    //5
			{
			textBox29.Visible=true;
			textBox30.Visible=true;
			textBox31.Visible=true;
			textBox32.Visible=true;
			textBox33.Visible=true;
			textBox34.Visible=true;
			}
			else if(textBox35.Visible == false)   //raw 6
			{
			textBox35.Visible=true;
			textBox40.Visible=true;
			textBox45.Visible=true;
			textBox50.Visible=true;
			textBox55.Visible=true;
			textBox60.Visible=true;
			}
			
			else if(textBox36.Visible == false)   //raw 7
			{
			textBox36.Visible=true;
			textBox41.Visible=true;
			textBox46.Visible=true;
			textBox51.Visible=true;
			textBox56.Visible=true;
			textBox61.Visible=true;
			}
			
			else if(textBox37.Visible == false)   //raw 8
			{
			textBox37.Visible=true;
			textBox42.Visible=true;
			textBox47.Visible=true;
			textBox52.Visible=true;
			textBox57.Visible=true;
			textBox62.Visible=true;
			}
			
			else if(textBox38.Visible == false)   //raw 9
			{
			textBox38.Visible=true;
			textBox43.Visible=true;
			textBox48.Visible=true;
			textBox53.Visible=true;
			textBox58.Visible=true;
			textBox63.Visible=true;
			}
			
			else if(textBox39.Visible == false)   //raw 10
			{
			textBox39.Visible=true;
			textBox44.Visible=true;
			textBox49.Visible=true;
			textBox54.Visible=true;
			textBox59.Visible=true;
			textBox64.Visible=true;
			}
			
			else if(textBox65.Visible == false)   //raw 11
			{
			textBox65.Visible=true;
			textBox66.Visible=true;
			textBox67.Visible=true;
			textBox68.Visible=true;
			textBox69.Visible=true;
			textBox70.Visible=true;
			}
				
			else if(textBox71.Visible == false)   //raw 12
			{
			textBox71.Visible=true;
			textBox72.Visible=true;
			textBox73.Visible=true;
			textBox74.Visible=true;
			textBox75.Visible=true;
			textBox76.Visible=true;
			}
			else
			{
				MessageBox.Show("You Can't add any row");
			}
		}
		
		
		
		
		
		//delete new raw
		void PictureBox12Click(object sender, EventArgs e)
		{
		
	    	if(textBox71.Visible == true)   //raw 12
			{
			textBox71.Visible=false;
			
			textBox72.Visible=false;
			textBox72.Text="0";
			
			textBox73.Visible=false;
			textBox73.Text="";
			
			textBox74.Visible=false;
			textBox74.Text="0";
			
			textBox75.Visible=false;
			textBox75.Text="";
			
			textBox76.Visible=false;
			textBox76.Text="0";
			}


	    	else if(textBox65.Visible == true)   //raw 11
			{
			textBox65.Visible=false;
			
			textBox66.Visible=false;
			textBox66.Text="0";
			
			textBox67.Visible=false;
			textBox67.Text="";
			
			textBox68.Visible=false;
			textBox68.Text="0";
			
			textBox69.Visible=false;
			textBox69.Text="";
			
			textBox70.Visible=false;
			textBox70.Text="0";
	    	}
	    	
	    	else if(textBox39.Visible == true)   //raw 10
			{
			textBox39.Visible=false;
			textBox44.Visible=false;
			textBox49.Visible=false;
			textBox54.Visible=false;
			textBox59.Visible=false;
			textBox64.Visible=false;
			textBox44.Text="0";
			textBox49.Text="";
			textBox54.Text="0";
			textBox59.Text="";
			textBox64.Text="0";
			}
		
		    	
			else if(textBox38.Visible == true)   //raw 9
			{
			textBox38.Visible=false;
			textBox43.Visible=false;
			textBox48.Visible=false;
			textBox53.Visible=false;
			textBox58.Visible=false;
			textBox63.Visible=false;
			
			textBox43.Text="0";
			textBox48.Text="";
			textBox53.Text="0";
			textBox58.Text="";
			textBox63.Text="0";
			}
		
			else if(textBox37.Visible == true)   //raw 8
			{
			textBox37.Visible=false;
			textBox42.Visible=false;
			textBox47.Visible=false;
			textBox52.Visible=false;
			textBox57.Visible=false;
			textBox62.Visible=false;
			
			textBox42.Text="0";
			textBox47.Text="";
			textBox52.Text="0";
			textBox57.Text="";
			textBox62.Text="0";	
			}
			
			else if(textBox36.Visible == true)   //raw 7
			{
			textBox36.Visible=false;
			textBox41.Visible=false;
			textBox46.Visible=false;
			textBox51.Visible=false;
			textBox56.Visible=false;
			textBox61.Visible=false;
			
			textBox41.Text="0";
			textBox46.Text="";
			textBox51.Text="0";
			textBox56.Text="";
			textBox61.Text="0";
			}
			
			
			else if(textBox35.Visible == true)   //raw 6
			{
			textBox35.Visible=false;
			textBox40.Visible=false;
			textBox45.Visible=false;
			textBox50.Visible=false;
			textBox55.Visible=false;
			textBox60.Visible=false;
			
			textBox40.Text="0";
			textBox45.Text="";
			textBox50.Text="0";
			textBox55.Text="";
			textBox60.Text="0";
			}
				
			else if(textBox29.Visible == true)    //5
			{
			textBox29.Visible=false;
			textBox30.Visible=false;
			textBox31.Visible=false;
			textBox32.Visible=false;
			textBox33.Visible=false;
			textBox34.Visible=false;
			
			
			textBox30.Text="0";
			textBox31.Text="";
			textBox32.Text="0";
			textBox33.Text="";
			textBox34.Text="0";
			}
			
			else if(textBox23.Visible == true)   //4
			{
			textBox23.Visible=false;
			textBox24.Visible=false;
			textBox25.Visible=false;
			textBox26.Visible=false;
			textBox27.Visible=false;
			textBox28.Visible=false;
			
			textBox24.Text="0";
			textBox25.Text="";
			textBox26.Text="0";
			textBox27.Text="";
			textBox28.Text="0";
			}
			
			else if(textBox17.Visible == true)    //3
			{
			textBox17.Visible=false;
			textBox18.Visible=false;
			textBox19.Visible=false;
			textBox20.Visible=false;
			textBox21.Visible=false;
			textBox22.Visible=false;
			
			textBox18.Text="0";
			textBox19.Text="";
			textBox20.Text="0";
			textBox21.Text="";
			textBox22.Text="0";
			}			
			
			
			else if(textBox11.Visible == true)      //2
			{
			textBox11.Visible=false;
			textBox12.Visible=false;
			textBox13.Visible=false;
			textBox14.Visible=false;
			textBox15.Visible=false;
			textBox16.Visible=false;
			
			textBox12.Text="0";
			textBox13.Text="";
			textBox14.Text="0";
			textBox15.Text="";
			textBox16.Text="0";
			}
			
			else
			{
				MessageBox.Show("You Can't Delete this row");
			}
			
			
			
		}
	
	
		//raw1 6  8   10
		void TextBox6TextChanged(object sender, EventArgs e)
		{
			double a=0;
			double b=0;
			{
			if(System.Text.RegularExpressions.Regex.IsMatch(textBox6.Text,"[^0-9^.^-]"))
			{
			textBox6.Text=textBox6.Text.Remove(textBox6.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.");
			}
	    	else if( textBox6.Text !=""  && textBox6.Text !=null && textBox6.Text !="." && textBox6.Text !="-")
		    {	
			try
			{
			a=Convert.ToDouble(textBox6.Text);
			c1=a;
			}
		    catch
		    {
			textBox6.Text=textBox6.Text.Remove(textBox6.Text.Length-1);
			}
			}
		    else
			{
			}
	        }
	 	    {
			if(System.Text.RegularExpressions.Regex.IsMatch( textBox8.Text, "[^0-9^.^-]"))
			{
			textBox8.Text=textBox8.Text.Remove(textBox8.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.)");
			}
			else if( textBox8.Text !=""  && textBox8.Text !=null && textBox8.Text !="." && textBox8.Text !="-")
		    {	
			try
			{
			b=Convert.ToDouble(textBox8.Text);
			b1=b;
			}
		    catch
		    {
			textBox8.Text=textBox8.Text.Remove(textBox8.Text.Length-1);
			}
			}
		    else
			{
			} 
	        }
			a1=(a-b);
			textBox10.Text=Convert.ToString(a-b);
			
	    }
	
	    //raw 2    14    16   18
	    
	
	
		
		void TextBox12TextChanged(object sender, EventArgs e)
		{
			double a=0;
			double b=0;
			{
			if(System.Text.RegularExpressions.Regex.IsMatch(textBox12.Text,"[^0-9^.^-]"))
			{
			textBox12.Text=textBox12.Text.Remove(textBox12.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.");
			}
	    	else if( textBox12.Text !=""  && textBox12.Text !=null && textBox12.Text !="." && textBox12.Text !="-")
		    {	
			try
			{
			a=Convert.ToDouble(textBox12.Text);
			c2=a;
			}
		    catch
		    {
			textBox12.Text=textBox12.Text.Remove(textBox12.Text.Length-1);
			}
			}
		    else
			{
			}
	        }
	 	    {
			if(System.Text.RegularExpressions.Regex.IsMatch( textBox14.Text, "[^0-9^.^-]"))
			{
			textBox14.Text=textBox14.Text.Remove(textBox14.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.)");
			}
			else if( textBox14.Text !=""  && textBox14.Text !=null && textBox14.Text !="." && textBox14.Text !="-")
		    {	
			try
			{
			b=Convert.ToDouble(textBox14.Text);
			b2=b;
			}
		    catch
		    {
			textBox14.Text=textBox14.Text.Remove(textBox14.Text.Length-1);
			}
			}
		    else
			{
			} 
	        }
			a2=(a-b);
			textBox16.Text=Convert.ToString(a-b);
			
		}
	
	
	//raw 3   18    20    22  
	
	
	
		
		void TextBox18TextChanged(object sender, EventArgs e)
		{
            double a=0;
			double b=0;
			{
			if(System.Text.RegularExpressions.Regex.IsMatch(textBox18.Text,"[^0-9^.^-]"))
			{
			textBox18.Text=textBox18.Text.Remove(textBox18.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.");
			}
	    	else if( textBox18.Text !=""  && textBox18.Text !=null && textBox18.Text !="." && textBox18.Text !="-")
		    {	
			try
			{
			a=Convert.ToDouble(textBox18.Text);
			c3=a;
			}
		    catch
		    {
			textBox18.Text=textBox18.Text.Remove(textBox18.Text.Length-1);
			}
			}
		    else
			{
			}
	        }
	 	    {
			if(System.Text.RegularExpressions.Regex.IsMatch( textBox20.Text, "[^0-9^.^-]"))
			{
			textBox20.Text=textBox20.Text.Remove(textBox20.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.)");
			}
			else if( textBox20.Text !=""  && textBox20.Text !=null && textBox20.Text !="." && textBox20.Text !="-")
		    {	
			try
			{
			b=Convert.ToDouble(textBox20.Text);
			b3=b;
			}
		    catch
		    {
			textBox20.Text=textBox20.Text.Remove(textBox20.Text.Length-1);
			}
			}
		    else
			{
			} 
	        }
			 a3=(a-b);
			textBox22.Text=Convert.ToString(a-b);	
           			
		}
		
		
		
		
		//raw4         24      26        28
		
		
		
		
		
		
		
		
		
		void TextBox24TextChanged(object sender, EventArgs e)
		{
         double a=0;
			double b=0;
			{
			if(System.Text.RegularExpressions.Regex.IsMatch(textBox24.Text,"[^0-9^.^-]"))
			{
			textBox24.Text=textBox24.Text.Remove(textBox24.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.");
			}
	    	else if( textBox24.Text !=""  && textBox24.Text !=null && textBox24.Text !="." && textBox24.Text !="-")
		    {	
			try
			{
			a=Convert.ToDouble(textBox24.Text);
			c4=a;
			}
		    catch
		    {
			textBox24.Text=textBox24.Text.Remove(textBox24.Text.Length-1);
			}
			}
		    else
			{
			}
	        }
	 	    {
			if(System.Text.RegularExpressions.Regex.IsMatch( textBox26.Text, "[^0-9^.^-]"))
			{
			textBox26.Text=textBox26.Text.Remove(textBox26.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.)");
			}
			else if( textBox26.Text !=""  && textBox26.Text !=null && textBox26.Text !="." && textBox26.Text !="-")
		    {	
			try
			{
			b=Convert.ToDouble(textBox26.Text);
			b4=b;
			}
		    catch
		    {
			textBox26.Text=textBox26.Text.Remove(textBox26.Text.Length-1);
			}
			}
		    else
			{
			} 
	        }
			a4=(a-b);
			textBox28.Text=Convert.ToString(a-b);	
						
		}
	

//raw 5       30         32          34

          

		
		void TextBox30TextChanged(object sender, EventArgs e)
		{
			double a=0;
			double b=0;
			{
			if(System.Text.RegularExpressions.Regex.IsMatch(textBox30.Text,"[^0-9^.^-]"))
			{
			textBox30.Text=textBox30.Text.Remove(textBox30.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.");
			}
	    	else if( textBox30.Text !=""  && textBox30.Text !=null && textBox30.Text !="." && textBox30.Text !="-")
		    {	
			try
			{
			a=Convert.ToDouble(textBox30.Text);
			c5=a;
			}
		    catch
		    {
			textBox30.Text=textBox30.Text.Remove(textBox30.Text.Length-1);
			}
			}
		    else
			{
			}
	        }
	 	    {
			if(System.Text.RegularExpressions.Regex.IsMatch( textBox32.Text, "[^0-9^.^-]"))
			{
			textBox32.Text=textBox32.Text.Remove(textBox32.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.)");
			}
			else if( textBox32.Text !=""  && textBox32.Text !=null && textBox32.Text !="." && textBox32.Text !="-")
		    {	
			try
			{
			b=Convert.ToDouble(textBox32.Text);
			b5=b;
			}
		    catch
		    {
			textBox32.Text=textBox32.Text.Remove(textBox32.Text.Length-1);
			}
			}
		    else
			{
			} 
	        }
			 a5=(a-b);
			textBox34.Text=Convert.ToString(a-b);
	       
		}
		
		
		//raw6      40         50     60     
		
		
		
		void TextBox40TextChanged(object sender, EventArgs e)
		{
			double a=0;
			double b=0;
			{
			if(System.Text.RegularExpressions.Regex.IsMatch(textBox40.Text,"[^0-9^.^-]"))
			{
			textBox40.Text=textBox40.Text.Remove(textBox40.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.");
			}
	    	else if( textBox40.Text !=""  && textBox40.Text !=null && textBox40.Text !="." && textBox40.Text !="-")
		    {	
			try
			{
			a=Convert.ToDouble(textBox40.Text);
			c6=a;
			}
		    catch
		    {
			textBox40.Text=textBox40.Text.Remove(textBox40.Text.Length-1);
			}
			}
		    else
			{
			}
	        }
	 	    {
			if(System.Text.RegularExpressions.Regex.IsMatch( textBox50.Text, "[^0-9^.^-]"))
			{
			textBox50.Text=textBox50.Text.Remove(textBox50.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.)");
			}
			else if( textBox50.Text !=""  && textBox50.Text !=null && textBox50.Text !="." && textBox50.Text !="-")
		    {	
			try
			{
			b=Convert.ToDouble(textBox50.Text);
			b6=b;
			}
		    catch
		    {
			textBox50.Text=textBox50.Text.Remove(textBox50.Text.Length-1);
			}
			}
		    else
			{
			} 
	        }
			 a6=(a-b);
			textBox60.Text=Convert.ToString(a-b);
	       
		}
		//raw7   41    51      61
		void TextBox41TextChanged(object sender, EventArgs e)
		{
			double a=0;
			double b=0;
			{
			if(System.Text.RegularExpressions.Regex.IsMatch(textBox41.Text,"[^0-9^.^-]"))
			{
			textBox41.Text=textBox41.Text.Remove(textBox41.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.");
			}
	    	else if( textBox41.Text !=""  && textBox41.Text !=null && textBox41.Text !="." && textBox41.Text !="-")
		    {	
			try
			{
			a=Convert.ToDouble(textBox41.Text);
			c7=a;
			}
		    catch
		    {
			textBox41.Text=textBox41.Text.Remove(textBox41.Text.Length-1);
			}
			}
		    else
			{
			}
	        }
	 	    {
			if(System.Text.RegularExpressions.Regex.IsMatch( textBox51.Text, "[^0-9^.^-]"))
			{
			textBox51.Text=textBox51.Text.Remove(textBox51.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.)");
			}
			else if( textBox51.Text !=""  && textBox51.Text !=null && textBox51.Text !="." && textBox51.Text !="-")
		    {	
			try
			{
			b=Convert.ToDouble(textBox51.Text);
			b7=b;
			}
		    catch
		    {
			textBox51.Text=textBox51.Text.Remove(textBox51.Text.Length-1);
			}
			}
		    else
			{
			} 
	        }
			 a7=(a-b);
			textBox61.Text=Convert.ToString(a-b);
		   
		}
		//raw8          42        52     62
		
		void TextBox42TextChanged(object sender, EventArgs e)
		{
			double a=0;
			double b=0;
			{
			if(System.Text.RegularExpressions.Regex.IsMatch(textBox42.Text,"[^0-9^.^-]"))
			{
			textBox42.Text=textBox42.Text.Remove(textBox42.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.");
			}
	    	else if( textBox42.Text !=""  && textBox42.Text !=null && textBox42.Text !="." && textBox42.Text !="-")
		    {	
			try
			{
			a=Convert.ToDouble(textBox42.Text);
			c8=a;
			}
		    catch
		    {
			textBox42.Text=textBox42.Text.Remove(textBox42.Text.Length-1);
			}
			}
		    else
			{
			}
	        }
	 	    {
			if(System.Text.RegularExpressions.Regex.IsMatch( textBox52.Text, "[^0-9^.^-]"))
			{
			textBox52.Text=textBox52.Text.Remove(textBox52.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.)");
			}
			else if( textBox52.Text !=""  && textBox52.Text !=null && textBox52.Text !="." && textBox52.Text !="-")
		    {	
			try
			{
			b=Convert.ToDouble(textBox52.Text);
			b8=b;
			}
		    catch
		    {
			textBox52.Text=textBox52.Text.Remove(textBox52.Text.Length-1);
			}
			}
		    else
			{
			} 
	        }
			a8=(a-b);
			textBox62.Text=Convert.ToString(a-b);
			
		}
		//raw9   43      53      63
		
		void TextBox43TextChanged(object sender, EventArgs e)
		{
			double a=0;
			double b=0;
			{
			if(System.Text.RegularExpressions.Regex.IsMatch(textBox43.Text,"[^0-9^.^-]"))
			{
			textBox43.Text=textBox43.Text.Remove(textBox43.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.");
			}
	    	else if( textBox43.Text !=""  && textBox43.Text !=null && textBox43.Text !="." && textBox43.Text !="-")
		    {	
			try
			{
			a=Convert.ToDouble(textBox43.Text);
			c9=a;
			}
		    catch
		    {
			textBox43.Text=textBox43.Text.Remove(textBox43.Text.Length-1);
			}
			}
		    else
			{
			}
	        }
	 	    {
			if(System.Text.RegularExpressions.Regex.IsMatch( textBox53.Text, "[^0-9^.^-]"))
			{
			textBox53.Text=textBox53.Text.Remove(textBox53.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.)");
			}
			else if( textBox53.Text !=""  && textBox53.Text !=null && textBox53.Text !="." && textBox53.Text !="-")
		    {	
			try
			{
			b=Convert.ToDouble(textBox53.Text);
			b9=b;
			}
		    catch
		    {
			textBox53.Text=textBox53.Text.Remove(textBox53.Text.Length-1);
			}
			}
		    else
			{
			} 
	        }
			a9=(a-b);
			textBox63.Text=Convert.ToString(a-b);
		    
		}
		//raw10   44        54          64
		
		void TextBox44TextChanged(object sender, EventArgs e)
		{
            double a=0;
			double b=0;
			{
			if(System.Text.RegularExpressions.Regex.IsMatch(textBox44.Text,"[^0-9^.^-]"))
			{
			textBox44.Text=textBox44.Text.Remove(textBox44.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.");
			}
	    	else if( textBox44.Text !=""  && textBox44.Text !=null && textBox44.Text !="." && textBox44.Text !="-")
		    {	
			try
			{
			a=Convert.ToDouble(textBox44.Text);
			c10=a;
			}
		    catch
		    {
			textBox44.Text=textBox44.Text.Remove(textBox44.Text.Length-1);
			}
			}
		    else
			{
			}
	        }
	 	    {
			if(System.Text.RegularExpressions.Regex.IsMatch( textBox54.Text, "[^0-9^.^-]"))
			{
			textBox54.Text=textBox54.Text.Remove(textBox54.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.)");
			}
			else if( textBox54.Text !=""  && textBox54.Text !=null && textBox54.Text !="." && textBox54.Text !="-")
		    {	
			try
			{
			b=Convert.ToDouble(textBox54.Text);
			b10=b;
			}
		    catch
		    {
			textBox54.Text=textBox54.Text.Remove(textBox54.Text.Length-1);
			}
			}
		    else
			{
			} 
	        }
			a10=(a-b);
			textBox64.Text=Convert.ToString(a-b);
			
		}			
		//raw11      66       68         70
		
		void TextBox66TextChanged(object sender, EventArgs e)
		{
            double a=0;
			double b=0;
			{
			if(System.Text.RegularExpressions.Regex.IsMatch(textBox66.Text,"[^0-9^.^-]"))
			{
			textBox66.Text=textBox66.Text.Remove(textBox66.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.");
			}
	    	else if( textBox66.Text !=""  && textBox66.Text !=null && textBox66.Text !="." && textBox66.Text !="-")
		    {	
			try
			{
			a=Convert.ToDouble(textBox66.Text);
			c11=a;
			}
		    catch
		    {
			textBox66.Text=textBox66.Text.Remove(textBox66.Text.Length-1);
			}
			}
		    else
			{
			}
	        }
	 	    {
			if(System.Text.RegularExpressions.Regex.IsMatch( textBox68.Text, "[^0-9^.^-]"))
			{
			textBox68.Text=textBox68.Text.Remove(textBox68.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.)");
			}
			else if( textBox68.Text !=""  && textBox68.Text !=null && textBox68.Text !="." && textBox68.Text !="-")
		    {	
			try
			{
			b=Convert.ToDouble(textBox68.Text);
			b11=b;
			}
		    catch
		    {
			textBox68.Text=textBox68.Text.Remove(textBox68.Text.Length-1);
			}
			}
		    else
			{
			} 
	        }
			a11=(a-b);
			textBox70.Text=Convert.ToString(a-b);
					
		}
		//raw12      72       74        76
		
		void TextBox72TextChanged(object sender, EventArgs e)
		{
            double a=0;
			double b=0;
			{
			if(System.Text.RegularExpressions.Regex.IsMatch(textBox72.Text,"[^0-9^.^-]"))
			{
			textBox72.Text=textBox72.Text.Remove(textBox72.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.");
			}
	    	else if( textBox72.Text !=""  && textBox72.Text !=null && textBox72.Text !="." && textBox72.Text !="-")
		    {	
			try
			{
			a=Convert.ToDouble(textBox72.Text);
			c12=a;
			}
		    catch
		    {
			textBox72.Text=textBox72.Text.Remove(textBox72.Text.Length-1);
			}
			}
		    else
			{
			}
	        }
	 	    {
			if(System.Text.RegularExpressions.Regex.IsMatch( textBox74.Text, "[^0-9^.^-]"))
			{
			textBox74.Text=textBox74.Text.Remove(textBox74.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.)");
			}
			else if( textBox74.Text !=""  && textBox74.Text !=null && textBox74.Text !="." && textBox74.Text !="-")
		    {	
			try
			{
			b=Convert.ToDouble(textBox74.Text);
			b12=b;
			}
		    catch
		    {
			textBox74.Text=textBox74.Text.Remove(textBox74.Text.Length-1);
			}
			}
		    else
			{
			} 
	        }
			a12=(a-b);
			textBox76.Text=Convert.ToString(a-b);
					
		}
		
		
		
		void TextBox10TextChanged(object sender, EventArgs e)
		{
	    //balance
	    sum=a1+a2+a3+a4+a5+a6+a7+a8+a9+a10+a11+a12;
	    label10.Text=Convert.ToString(sum);
	    label9.Text=Convert.ToString(sum);
	  
	    //cost
	    sum1=b1+b2+b3+b4+b5+b6+b7+b8+b9+b10+b11+b12;
	    label8.Text=Convert.ToString(sum1);
	    label11.Text=Convert.ToString(sum1);
	    //income
	    sum2=c1+c2+c3+c4+c5+c6+c7+c8+c9+c10+c11+c12;
	    label2.Text=Convert.ToString(sum2);
	    //remaining limit
	    lim=Convert.ToDouble(label16.Text);
	    rl=lim-sum1;
	    label12.Text=Convert.ToString(rl);
	        //20% red     70%  yeollo  30% green
	      r=lim*0.1;
	     
	       if(rl==r)
	       {
	     	MessageBox.Show("You have finished 90% of your limit");
	       }
	     
	    }
	
	
	
	
	//calender
		
		void ShowToolStripMenuItemClick(object sender, EventArgs e)
		{
			
         monthCalendar1.Visible=true;	
		 i=1;
		}
		
		
		
		void SToolStripMenuItemClick(object sender, EventArgs e)
		{
			monthCalendar1.Visible=false;
			i=0;
		}
	//close
		void cL()
		{   
			panel2.Visible=false;
			pictureBox7.Visible=false;
			pictureBox2.Visible=true;
			
			label1.BackColor=Color.LightSeaGreen;
			pictureBox10.Visible=false;
			monthCalendar1.Visible=false;
			panel3.Visible=false;
			
			scrreen.Visible=false;
		
		
		}
		//close
		void CloseToolStripMenuItemClick(object sender, EventArgs e)
		{
			cL();
		}
		//rate us
		void RateUsToolStripMenuItemClick(object sender, EventArgs e)
		{
		MessageBox.Show("Not available at this Moment");
		}
		//user guide
		void UserGuideToolStripMenuItemClick(object sender, EventArgs e)
		{
        MessageBox.Show("Not available at this Moment");			
		}
		//support
		void SupportToolStripMenuItemClick(object sender, EventArgs e)
		{
		MessageBox.Show("Not available at this Moment");
		}
		//report an abuse
		void ReportAbuseToolStripMenuItemClick(object sender, EventArgs e)
		{
		MessageBox.Show("Not available at this Moment");
		}
		//suggestion
		void SuggestionToolStripMenuItemClick(object sender, EventArgs e)
		{
		MessageBox.Show("Not available at this Moment");	
		}
		//walet
		void WaletToolStripMenuItemClick(object sender, EventArgs e)
		{
			MessageBox.Show("Not available at this Moment");
		}
		//developer
		void DeveloperToolStripMenuItemClick(object sender, EventArgs e)
		{
			MessageBox.Show("Developed   by   Hasanur Rahman Shishir\nGraphics      by   Md.Nadim Mahmud Chifat");
		}
		
	//pie
		
		void PieChartToolStripMenuItemClick(object sender, EventArgs e)
		{
			MessageBox.Show("Not available at this Moment");
		}
		//bar chart
		void BarChartToolStripMenuItemClick(object sender, EventArgs e)
		{
            MessageBox.Show("Not available at this Moment");			
		}
   //limit
  
		//budget
		void TextBox2TextChanged(object sender, EventArgs e)
		{
			{
			if(System.Text.RegularExpressions.Regex.IsMatch(textBox2.Text,"[^0-9^.^-]"))
			{
			textBox2.Text=textBox2.Text.Remove(textBox2.Text.Length-1);
			MessageBox.Show("Please input valid Character(0,1,2,3,4,5,6,7,8,9,.");
			}
	    	else if( textBox2.Text !=""  && textBox2.Text !=null && textBox2.Text !="." && textBox2.Text !="-")
		    {	
			try
			{
			bud=Convert.ToDouble(textBox2.Text);
			
			}
		    catch
		    {
			textBox2.Text=textBox2.Text.Remove(textBox2.Text.Length-1);
			}
			}
		    else
			{
			}
	        }
			lim=bud/day;
			label16.Text=Convert.ToString(lim);
	    	s=1;
		}
		//bdt
		void ComboBox1SelectedIndexChanged(object sender, EventArgs e)
		{
			
		}
		//password
		void TextBox4TextChanged(object sender, EventArgs e)
		{
			
		}
		//monthly
		void TextBox3TextChanged(object sender, EventArgs e)
		{
			
		}
		//new 
		void ToolStripMenuItem2Click(object sender, EventArgs e)
		{
			MessageBox.Show("Not available at this Moment");	
		}
	//open	
		void OpenToolStripMenuItemClick(object sender, EventArgs e)
		{
			//MessageBox.Show("Not available at this Moment");	
		}
		//save
		void SaveToolStripMenuItemClick(object sender, EventArgs e)
		{
			MessageBox.Show("Not available at this Moment");	
		}
		//save as
		void SaveAsToolStripMenuItemClick(object sender, EventArgs e)
		{
			MessageBox.Show("Not available at this Moment");	
		}
		//print
		void PrintToolStripMenuItemClick(object sender, EventArgs e)
		{
			//MessageBox.Show("Not available at this Moment");	
		}
	}}
