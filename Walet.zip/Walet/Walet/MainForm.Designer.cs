﻿/*
 * Created by SharpDevelop.
 * User: ar gadget
 * Date: 6/2/2020
 * Time: 9:19 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace Walet
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
			this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
			this.limitChangeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.passwordChangeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.calenderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.showToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.sToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.stastisticsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.pieChartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.barChartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.waletToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.developerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.rateUsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.userGuideToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.supportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.reportAbuseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.suggestionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.panel1 = new System.Windows.Forms.Panel();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.pictureBox6 = new System.Windows.Forms.PictureBox();
			this.pictureBox5 = new System.Windows.Forms.PictureBox();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.trackBar1 = new System.Windows.Forms.TrackBar();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.pictureBox4 = new System.Windows.Forms.PictureBox();
			this.pictureBox3 = new System.Windows.Forms.PictureBox();
			this.pictureBox7 = new System.Windows.Forms.PictureBox();
			this.pictureBox8 = new System.Windows.Forms.PictureBox();
			this.pictureBox9 = new System.Windows.Forms.PictureBox();
			this.pictureBox10 = new System.Windows.Forms.PictureBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this.label9 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.textBox76 = new System.Windows.Forms.TextBox();
			this.textBox70 = new System.Windows.Forms.TextBox();
			this.textBox64 = new System.Windows.Forms.TextBox();
			this.textBox34 = new System.Windows.Forms.TextBox();
			this.textBox63 = new System.Windows.Forms.TextBox();
			this.textBox28 = new System.Windows.Forms.TextBox();
			this.textBox62 = new System.Windows.Forms.TextBox();
			this.textBox22 = new System.Windows.Forms.TextBox();
			this.textBox61 = new System.Windows.Forms.TextBox();
			this.textBox16 = new System.Windows.Forms.TextBox();
			this.textBox60 = new System.Windows.Forms.TextBox();
			this.textBox10 = new System.Windows.Forms.TextBox();
			this.textBox75 = new System.Windows.Forms.TextBox();
			this.textBox69 = new System.Windows.Forms.TextBox();
			this.textBox59 = new System.Windows.Forms.TextBox();
			this.textBox33 = new System.Windows.Forms.TextBox();
			this.textBox58 = new System.Windows.Forms.TextBox();
			this.textBox27 = new System.Windows.Forms.TextBox();
			this.textBox57 = new System.Windows.Forms.TextBox();
			this.textBox21 = new System.Windows.Forms.TextBox();
			this.textBox56 = new System.Windows.Forms.TextBox();
			this.textBox15 = new System.Windows.Forms.TextBox();
			this.textBox55 = new System.Windows.Forms.TextBox();
			this.textBox9 = new System.Windows.Forms.TextBox();
			this.textBox74 = new System.Windows.Forms.TextBox();
			this.textBox68 = new System.Windows.Forms.TextBox();
			this.textBox54 = new System.Windows.Forms.TextBox();
			this.textBox32 = new System.Windows.Forms.TextBox();
			this.textBox53 = new System.Windows.Forms.TextBox();
			this.textBox26 = new System.Windows.Forms.TextBox();
			this.textBox52 = new System.Windows.Forms.TextBox();
			this.textBox20 = new System.Windows.Forms.TextBox();
			this.textBox51 = new System.Windows.Forms.TextBox();
			this.textBox14 = new System.Windows.Forms.TextBox();
			this.textBox50 = new System.Windows.Forms.TextBox();
			this.textBox8 = new System.Windows.Forms.TextBox();
			this.textBox73 = new System.Windows.Forms.TextBox();
			this.textBox67 = new System.Windows.Forms.TextBox();
			this.textBox49 = new System.Windows.Forms.TextBox();
			this.textBox31 = new System.Windows.Forms.TextBox();
			this.textBox48 = new System.Windows.Forms.TextBox();
			this.textBox25 = new System.Windows.Forms.TextBox();
			this.textBox47 = new System.Windows.Forms.TextBox();
			this.textBox19 = new System.Windows.Forms.TextBox();
			this.textBox46 = new System.Windows.Forms.TextBox();
			this.textBox13 = new System.Windows.Forms.TextBox();
			this.textBox45 = new System.Windows.Forms.TextBox();
			this.textBox7 = new System.Windows.Forms.TextBox();
			this.textBox72 = new System.Windows.Forms.TextBox();
			this.textBox66 = new System.Windows.Forms.TextBox();
			this.textBox44 = new System.Windows.Forms.TextBox();
			this.textBox43 = new System.Windows.Forms.TextBox();
			this.textBox30 = new System.Windows.Forms.TextBox();
			this.textBox42 = new System.Windows.Forms.TextBox();
			this.textBox24 = new System.Windows.Forms.TextBox();
			this.textBox41 = new System.Windows.Forms.TextBox();
			this.textBox18 = new System.Windows.Forms.TextBox();
			this.textBox40 = new System.Windows.Forms.TextBox();
			this.textBox12 = new System.Windows.Forms.TextBox();
			this.textBox71 = new System.Windows.Forms.TextBox();
			this.textBox65 = new System.Windows.Forms.TextBox();
			this.textBox39 = new System.Windows.Forms.TextBox();
			this.textBox6 = new System.Windows.Forms.TextBox();
			this.textBox38 = new System.Windows.Forms.TextBox();
			this.textBox29 = new System.Windows.Forms.TextBox();
			this.textBox37 = new System.Windows.Forms.TextBox();
			this.textBox23 = new System.Windows.Forms.TextBox();
			this.textBox36 = new System.Windows.Forms.TextBox();
			this.textBox17 = new System.Windows.Forms.TextBox();
			this.textBox35 = new System.Windows.Forms.TextBox();
			this.textBox11 = new System.Windows.Forms.TextBox();
			this.textBox5 = new System.Windows.Forms.TextBox();
			this.balance = new System.Windows.Forms.Label();
			this.reson2 = new System.Windows.Forms.Label();
			this.reson1 = new System.Windows.Forms.Label();
			this.cost = new System.Windows.Forms.Label();
			this.slno = new System.Windows.Forms.Label();
			this.income = new System.Windows.Forms.Label();
			this.panel3 = new System.Windows.Forms.Panel();
			this.pictureBox12 = new System.Windows.Forms.PictureBox();
			this.pictureBox11 = new System.Windows.Forms.PictureBox();
			this.scrreen = new System.Windows.Forms.Panel();
			this.label15 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.pictureBox16 = new System.Windows.Forms.PictureBox();
			this.pictureBox14 = new System.Windows.Forms.PictureBox();
			this.pictureBox13 = new System.Windows.Forms.PictureBox();
			this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
			this.label1 = new System.Windows.Forms.Label();
			this.menuStrip1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
			this.panel2.SuspendLayout();
			this.panel3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
			this.scrreen.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
			this.SuspendLayout();
			// 
			// menuStrip1
			// 
			this.menuStrip1.BackColor = System.Drawing.Color.LightSeaGreen;
			this.menuStrip1.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.fileToolStripMenuItem,
									this.toolStripMenuItem3,
									this.viewToolStripMenuItem,
									this.stastisticsToolStripMenuItem,
									this.aboutToolStripMenuItem,
									this.helpToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(1584, 37);
			this.menuStrip1.TabIndex = 0;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// fileToolStripMenuItem
			// 
			this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.toolStripMenuItem2,
									this.openToolStripMenuItem,
									this.closeToolStripMenuItem,
									this.saveToolStripMenuItem,
									this.saveAsToolStripMenuItem,
									this.printToolStripMenuItem,
									this.exitToolStripMenuItem});
			this.fileToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
			this.fileToolStripMenuItem.Size = new System.Drawing.Size(60, 33);
			this.fileToolStripMenuItem.Text = "File";
			// 
			// toolStripMenuItem2
			// 
			this.toolStripMenuItem2.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.toolStripMenuItem2.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.toolStripMenuItem2.Name = "toolStripMenuItem2";
			this.toolStripMenuItem2.Size = new System.Drawing.Size(135, 26);
			this.toolStripMenuItem2.Text = "New";
			this.toolStripMenuItem2.Click += new System.EventHandler(this.ToolStripMenuItem2Click);
			// 
			// openToolStripMenuItem
			// 
			this.openToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.openToolStripMenuItem.Name = "openToolStripMenuItem";
			this.openToolStripMenuItem.Size = new System.Drawing.Size(135, 26);
			this.openToolStripMenuItem.Text = "Open";
			this.openToolStripMenuItem.Click += new System.EventHandler(this.OpenToolStripMenuItemClick);
			// 
			// closeToolStripMenuItem
			// 
			this.closeToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
			this.closeToolStripMenuItem.Size = new System.Drawing.Size(135, 26);
			this.closeToolStripMenuItem.Text = "Close";
			this.closeToolStripMenuItem.Click += new System.EventHandler(this.CloseToolStripMenuItemClick);
			// 
			// saveToolStripMenuItem
			// 
			this.saveToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.saveToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
			this.saveToolStripMenuItem.Size = new System.Drawing.Size(135, 26);
			this.saveToolStripMenuItem.Text = "Save";
			this.saveToolStripMenuItem.Click += new System.EventHandler(this.SaveToolStripMenuItemClick);
			// 
			// saveAsToolStripMenuItem
			// 
			this.saveAsToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.saveAsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
			this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(135, 26);
			this.saveAsToolStripMenuItem.Text = "Save As";
			this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.SaveAsToolStripMenuItemClick);
			// 
			// printToolStripMenuItem
			// 
			this.printToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.printToolStripMenuItem.Name = "printToolStripMenuItem";
			this.printToolStripMenuItem.Size = new System.Drawing.Size(135, 26);
			this.printToolStripMenuItem.Text = "Print";
			this.printToolStripMenuItem.Click += new System.EventHandler(this.PrintToolStripMenuItemClick);
			// 
			// exitToolStripMenuItem
			// 
			this.exitToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.exitToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
			this.exitToolStripMenuItem.Size = new System.Drawing.Size(135, 26);
			this.exitToolStripMenuItem.Text = "Exit";
			this.exitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItemClick);
			// 
			// toolStripMenuItem3
			// 
			this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.limitChangeToolStripMenuItem,
									this.passwordChangeToolStripMenuItem});
			this.toolStripMenuItem3.Name = "toolStripMenuItem3";
			this.toolStripMenuItem3.Size = new System.Drawing.Size(65, 33);
			this.toolStripMenuItem3.Text = "Edit";
			// 
			// limitChangeToolStripMenuItem
			// 
			this.limitChangeToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.limitChangeToolStripMenuItem.Name = "limitChangeToolStripMenuItem";
			this.limitChangeToolStripMenuItem.Size = new System.Drawing.Size(204, 26);
			this.limitChangeToolStripMenuItem.Text = "Limit Change";
			// 
			// passwordChangeToolStripMenuItem
			// 
			this.passwordChangeToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.passwordChangeToolStripMenuItem.Name = "passwordChangeToolStripMenuItem";
			this.passwordChangeToolStripMenuItem.Size = new System.Drawing.Size(204, 26);
			this.passwordChangeToolStripMenuItem.Text = "Password Change";
			// 
			// viewToolStripMenuItem
			// 
			this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.calenderToolStripMenuItem});
			this.viewToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
			this.viewToolStripMenuItem.Size = new System.Drawing.Size(74, 33);
			this.viewToolStripMenuItem.Text = "View";
			// 
			// calenderToolStripMenuItem
			// 
			this.calenderToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.showToolStripMenuItem,
									this.sToolStripMenuItem});
			this.calenderToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.calenderToolStripMenuItem.Name = "calenderToolStripMenuItem";
			this.calenderToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
			this.calenderToolStripMenuItem.Text = "Calender";
			// 
			// showToolStripMenuItem
			// 
			this.showToolStripMenuItem.Name = "showToolStripMenuItem";
			this.showToolStripMenuItem.Size = new System.Drawing.Size(118, 26);
			this.showToolStripMenuItem.Text = "Show";
			this.showToolStripMenuItem.Click += new System.EventHandler(this.ShowToolStripMenuItemClick);
			// 
			// sToolStripMenuItem
			// 
			this.sToolStripMenuItem.Name = "sToolStripMenuItem";
			this.sToolStripMenuItem.Size = new System.Drawing.Size(118, 26);
			this.sToolStripMenuItem.Text = "Hide";
			this.sToolStripMenuItem.Click += new System.EventHandler(this.SToolStripMenuItemClick);
			// 
			// stastisticsToolStripMenuItem
			// 
			this.stastisticsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.pieChartToolStripMenuItem,
									this.barChartToolStripMenuItem});
			this.stastisticsToolStripMenuItem.Name = "stastisticsToolStripMenuItem";
			this.stastisticsToolStripMenuItem.Size = new System.Drawing.Size(124, 33);
			this.stastisticsToolStripMenuItem.Text = "Stastistics";
			// 
			// pieChartToolStripMenuItem
			// 
			this.pieChartToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.pieChartToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.pieChartToolStripMenuItem.Name = "pieChartToolStripMenuItem";
			this.pieChartToolStripMenuItem.Size = new System.Drawing.Size(150, 26);
			this.pieChartToolStripMenuItem.Text = "Pie Chart";
			this.pieChartToolStripMenuItem.Click += new System.EventHandler(this.PieChartToolStripMenuItemClick);
			// 
			// barChartToolStripMenuItem
			// 
			this.barChartToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.barChartToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.barChartToolStripMenuItem.Name = "barChartToolStripMenuItem";
			this.barChartToolStripMenuItem.Size = new System.Drawing.Size(150, 26);
			this.barChartToolStripMenuItem.Text = "Bar Chart";
			this.barChartToolStripMenuItem.Click += new System.EventHandler(this.BarChartToolStripMenuItemClick);
			// 
			// aboutToolStripMenuItem
			// 
			this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.waletToolStripMenuItem,
									this.developerToolStripMenuItem,
									this.rateUsToolStripMenuItem});
			this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
			this.aboutToolStripMenuItem.Size = new System.Drawing.Size(87, 33);
			this.aboutToolStripMenuItem.Text = "About";
			// 
			// waletToolStripMenuItem
			// 
			this.waletToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.waletToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.waletToolStripMenuItem.Name = "waletToolStripMenuItem";
			this.waletToolStripMenuItem.Size = new System.Drawing.Size(151, 26);
			this.waletToolStripMenuItem.Text = "Walet";
			this.waletToolStripMenuItem.Click += new System.EventHandler(this.WaletToolStripMenuItemClick);
			// 
			// developerToolStripMenuItem
			// 
			this.developerToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.developerToolStripMenuItem.Name = "developerToolStripMenuItem";
			this.developerToolStripMenuItem.Size = new System.Drawing.Size(151, 26);
			this.developerToolStripMenuItem.Text = "Developer";
			this.developerToolStripMenuItem.Click += new System.EventHandler(this.DeveloperToolStripMenuItemClick);
			// 
			// rateUsToolStripMenuItem
			// 
			this.rateUsToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.rateUsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.rateUsToolStripMenuItem.Name = "rateUsToolStripMenuItem";
			this.rateUsToolStripMenuItem.Size = new System.Drawing.Size(151, 26);
			this.rateUsToolStripMenuItem.Text = "Rate Us";
			this.rateUsToolStripMenuItem.Click += new System.EventHandler(this.RateUsToolStripMenuItemClick);
			// 
			// helpToolStripMenuItem
			// 
			this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
									this.userGuideToolStripMenuItem,
									this.supportToolStripMenuItem,
									this.reportAbuseToolStripMenuItem,
									this.suggestionToolStripMenuItem});
			this.helpToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
			this.helpToolStripMenuItem.Size = new System.Drawing.Size(74, 33);
			this.helpToolStripMenuItem.Text = "Help";
			// 
			// userGuideToolStripMenuItem
			// 
			this.userGuideToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.userGuideToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.userGuideToolStripMenuItem.Name = "userGuideToolStripMenuItem";
			this.userGuideToolStripMenuItem.Size = new System.Drawing.Size(192, 26);
			this.userGuideToolStripMenuItem.Text = "User Guide";
			this.userGuideToolStripMenuItem.Click += new System.EventHandler(this.UserGuideToolStripMenuItemClick);
			// 
			// supportToolStripMenuItem
			// 
			this.supportToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.supportToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.supportToolStripMenuItem.Name = "supportToolStripMenuItem";
			this.supportToolStripMenuItem.Size = new System.Drawing.Size(192, 26);
			this.supportToolStripMenuItem.Text = "Support";
			this.supportToolStripMenuItem.Click += new System.EventHandler(this.SupportToolStripMenuItemClick);
			// 
			// reportAbuseToolStripMenuItem
			// 
			this.reportAbuseToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.reportAbuseToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.reportAbuseToolStripMenuItem.Name = "reportAbuseToolStripMenuItem";
			this.reportAbuseToolStripMenuItem.Size = new System.Drawing.Size(192, 26);
			this.reportAbuseToolStripMenuItem.Text = "Report an abuse";
			this.reportAbuseToolStripMenuItem.Click += new System.EventHandler(this.ReportAbuseToolStripMenuItemClick);
			// 
			// suggestionToolStripMenuItem
			// 
			this.suggestionToolStripMenuItem.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.suggestionToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.suggestionToolStripMenuItem.Name = "suggestionToolStripMenuItem";
			this.suggestionToolStripMenuItem.Size = new System.Drawing.Size(192, 26);
			this.suggestionToolStripMenuItem.Text = "Suggestion";
			this.suggestionToolStripMenuItem.Click += new System.EventHandler(this.SuggestionToolStripMenuItemClick);
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.LightSeaGreen;
			this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
			this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBox1.Location = new System.Drawing.Point(1535, 0);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(37, 37);
			this.pictureBox1.TabIndex = 2;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Click += new System.EventHandler(this.PictureBox1Click);
			// 
			// pictureBox2
			// 
			this.pictureBox2.BackColor = System.Drawing.Color.LightSeaGreen;
			this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
			this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
			this.pictureBox2.Location = new System.Drawing.Point(31, 386);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(100, 97);
			this.pictureBox2.TabIndex = 8;
			this.pictureBox2.TabStop = false;
			this.pictureBox2.Tag = "";
			this.pictureBox2.Click += new System.EventHandler(this.PictureBox2Click);
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.LightSeaGreen;
			this.panel1.Controls.Add(this.textBox4);
			this.panel1.Controls.Add(this.pictureBox6);
			this.panel1.Controls.Add(this.pictureBox5);
			this.panel1.Controls.Add(this.comboBox1);
			this.panel1.Controls.Add(this.textBox3);
			this.panel1.Controls.Add(this.trackBar1);
			this.panel1.Controls.Add(this.textBox2);
			this.panel1.Controls.Add(this.label7);
			this.panel1.Controls.Add(this.label6);
			this.panel1.Controls.Add(this.label5);
			this.panel1.Controls.Add(this.label4);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.textBox1);
			this.panel1.Controls.Add(this.pictureBox4);
			this.panel1.Controls.Add(this.pictureBox3);
			this.panel1.Location = new System.Drawing.Point(518, 164);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(495, 325);
			this.panel1.TabIndex = 10;
			this.panel1.Visible = false;
			// 
			// textBox4
			// 
			this.textBox4.Location = new System.Drawing.Point(121, 212);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(168, 20);
			this.textBox4.TabIndex = 9;
			this.textBox4.UseSystemPasswordChar = true;
			this.textBox4.Visible = false;
			this.textBox4.TextChanged += new System.EventHandler(this.TextBox4TextChanged);
			// 
			// pictureBox6
			// 
			this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
			this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.pictureBox6.Location = new System.Drawing.Point(121, 178);
			this.pictureBox6.Name = "pictureBox6";
			this.pictureBox6.Size = new System.Drawing.Size(52, 46);
			this.pictureBox6.TabIndex = 10;
			this.pictureBox6.TabStop = false;
			this.pictureBox6.Click += new System.EventHandler(this.PictureBox6Click);
			// 
			// pictureBox5
			// 
			this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
			this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.pictureBox5.Location = new System.Drawing.Point(121, 178);
			this.pictureBox5.Name = "pictureBox5";
			this.pictureBox5.Size = new System.Drawing.Size(52, 46);
			this.pictureBox5.TabIndex = 10;
			this.pictureBox5.TabStop = false;
			this.pictureBox5.Click += new System.EventHandler(this.PictureBox5Click);
			// 
			// comboBox1
			// 
			this.comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			this.comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Items.AddRange(new object[] {
									"BDT",
									"USD",
									"INR"});
			this.comboBox1.Location = new System.Drawing.Point(306, 90);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(168, 21);
			this.comboBox1.TabIndex = 8;
			this.comboBox1.Text = "BDT";
			this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.ComboBox1SelectedIndexChanged);
			// 
			// textBox3
			// 
			this.textBox3.AutoCompleteCustomSource.AddRange(new string[] {
									"Monthly"});
			this.textBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
			this.textBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
			this.textBox3.Location = new System.Drawing.Point(121, 129);
			this.textBox3.Name = "textBox3";
			this.textBox3.ReadOnly = true;
			this.textBox3.Size = new System.Drawing.Size(168, 20);
			this.textBox3.TabIndex = 7;
			this.textBox3.Text = "Monthly";
			this.textBox3.TextChanged += new System.EventHandler(this.TextBox3TextChanged);
			// 
			// trackBar1
			// 
			this.trackBar1.Location = new System.Drawing.Point(306, 126);
			this.trackBar1.Name = "trackBar1";
			this.trackBar1.Size = new System.Drawing.Size(104, 45);
			this.trackBar1.SmallChange = 5;
			this.trackBar1.TabIndex = 6;
			this.trackBar1.TickFrequency = 5;
			this.trackBar1.Value = 10;
			this.trackBar1.Scroll += new System.EventHandler(this.TrackBar1Scroll);
			// 
			// textBox2
			// 
			this.textBox2.AllowDrop = true;
			this.textBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			this.textBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
			this.textBox2.Location = new System.Drawing.Point(121, 90);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(168, 20);
			this.textBox2.TabIndex = 5;
			this.textBox2.Text = "0";
			this.textBox2.TextChanged += new System.EventHandler(this.TextBox2TextChanged);
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Sitka Text", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.Location = new System.Drawing.Point(11, 208);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(102, 27);
			this.label7.TabIndex = 4;
			this.label7.Text = "Set password";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label7.Visible = false;
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Sitka Text", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.Location = new System.Drawing.Point(13, 173);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(75, 27);
			this.label6.TabIndex = 4;
			this.label6.Text = "Password";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Sitka Text", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.label5.Location = new System.Drawing.Point(16, 89);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(88, 27);
			this.label5.TabIndex = 4;
			this.label5.Text = "Set Budget";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Sitka Text", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.Location = new System.Drawing.Point(11, 46);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(107, 27);
			this.label4.TabIndex = 4;
			this.label4.Text = "Account Name";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(-70, 44);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(100, 23);
			this.label3.TabIndex = 3;
			this.label3.Text = "label3";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(121, 51);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(353, 20);
			this.textBox1.TabIndex = 2;
			this.textBox1.Text = "New Acc1";
			this.textBox1.TextChanged += new System.EventHandler(this.TextBox1TextChanged);
			// 
			// pictureBox4
			// 
			this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
			this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pictureBox4.Location = new System.Drawing.Point(224, 269);
			this.pictureBox4.Name = "pictureBox4";
			this.pictureBox4.Size = new System.Drawing.Size(50, 50);
			this.pictureBox4.TabIndex = 1;
			this.pictureBox4.TabStop = false;
			this.pictureBox4.Click += new System.EventHandler(this.PictureBox4Click);
			// 
			// pictureBox3
			// 
			this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
			this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pictureBox3.Location = new System.Drawing.Point(1, 1);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new System.Drawing.Size(30, 30);
			this.pictureBox3.TabIndex = 0;
			this.pictureBox3.TabStop = false;
			this.pictureBox3.Click += new System.EventHandler(this.PictureBox3Click);
			// 
			// pictureBox7
			// 
			this.pictureBox7.BackColor = System.Drawing.Color.LightSeaGreen;
			this.pictureBox7.Location = new System.Drawing.Point(258, 37);
			this.pictureBox7.Name = "pictureBox7";
			this.pictureBox7.Size = new System.Drawing.Size(2, 819);
			this.pictureBox7.TabIndex = 11;
			this.pictureBox7.TabStop = false;
			this.pictureBox7.Visible = false;
			// 
			// pictureBox8
			// 
			this.pictureBox8.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox8.BackgroundImage")));
			this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pictureBox8.Location = new System.Drawing.Point(6, 526);
			this.pictureBox8.Name = "pictureBox8";
			this.pictureBox8.Size = new System.Drawing.Size(246, 69);
			this.pictureBox8.TabIndex = 12;
			this.pictureBox8.TabStop = false;
			this.pictureBox8.Visible = false;
			// 
			// pictureBox9
			// 
			this.pictureBox9.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox9.BackgroundImage")));
			this.pictureBox9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pictureBox9.Location = new System.Drawing.Point(6, 617);
			this.pictureBox9.Name = "pictureBox9";
			this.pictureBox9.Size = new System.Drawing.Size(246, 69);
			this.pictureBox9.TabIndex = 12;
			this.pictureBox9.TabStop = false;
			this.pictureBox9.Visible = false;
			// 
			// pictureBox10
			// 
			this.pictureBox10.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox10.BackgroundImage")));
			this.pictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.pictureBox10.Location = new System.Drawing.Point(6, 49);
			this.pictureBox10.Name = "pictureBox10";
			this.pictureBox10.Size = new System.Drawing.Size(248, 420);
			this.pictureBox10.TabIndex = 13;
			this.pictureBox10.TabStop = false;
			this.pictureBox10.Visible = false;
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.label9);
			this.panel2.Controls.Add(this.label8);
			this.panel2.Controls.Add(this.label2);
			this.panel2.Controls.Add(this.textBox76);
			this.panel2.Controls.Add(this.textBox70);
			this.panel2.Controls.Add(this.textBox64);
			this.panel2.Controls.Add(this.textBox34);
			this.panel2.Controls.Add(this.textBox63);
			this.panel2.Controls.Add(this.textBox28);
			this.panel2.Controls.Add(this.textBox62);
			this.panel2.Controls.Add(this.textBox22);
			this.panel2.Controls.Add(this.textBox61);
			this.panel2.Controls.Add(this.textBox16);
			this.panel2.Controls.Add(this.textBox60);
			this.panel2.Controls.Add(this.textBox10);
			this.panel2.Controls.Add(this.textBox75);
			this.panel2.Controls.Add(this.textBox69);
			this.panel2.Controls.Add(this.textBox59);
			this.panel2.Controls.Add(this.textBox33);
			this.panel2.Controls.Add(this.textBox58);
			this.panel2.Controls.Add(this.textBox27);
			this.panel2.Controls.Add(this.textBox57);
			this.panel2.Controls.Add(this.textBox21);
			this.panel2.Controls.Add(this.textBox56);
			this.panel2.Controls.Add(this.textBox15);
			this.panel2.Controls.Add(this.textBox55);
			this.panel2.Controls.Add(this.textBox9);
			this.panel2.Controls.Add(this.textBox74);
			this.panel2.Controls.Add(this.textBox68);
			this.panel2.Controls.Add(this.textBox54);
			this.panel2.Controls.Add(this.textBox32);
			this.panel2.Controls.Add(this.textBox53);
			this.panel2.Controls.Add(this.textBox26);
			this.panel2.Controls.Add(this.textBox52);
			this.panel2.Controls.Add(this.textBox20);
			this.panel2.Controls.Add(this.textBox51);
			this.panel2.Controls.Add(this.textBox14);
			this.panel2.Controls.Add(this.textBox50);
			this.panel2.Controls.Add(this.textBox8);
			this.panel2.Controls.Add(this.textBox73);
			this.panel2.Controls.Add(this.textBox67);
			this.panel2.Controls.Add(this.textBox49);
			this.panel2.Controls.Add(this.textBox31);
			this.panel2.Controls.Add(this.textBox48);
			this.panel2.Controls.Add(this.textBox25);
			this.panel2.Controls.Add(this.textBox47);
			this.panel2.Controls.Add(this.textBox19);
			this.panel2.Controls.Add(this.textBox46);
			this.panel2.Controls.Add(this.textBox13);
			this.panel2.Controls.Add(this.textBox45);
			this.panel2.Controls.Add(this.textBox7);
			this.panel2.Controls.Add(this.textBox72);
			this.panel2.Controls.Add(this.textBox66);
			this.panel2.Controls.Add(this.textBox44);
			this.panel2.Controls.Add(this.textBox43);
			this.panel2.Controls.Add(this.textBox30);
			this.panel2.Controls.Add(this.textBox42);
			this.panel2.Controls.Add(this.textBox24);
			this.panel2.Controls.Add(this.textBox41);
			this.panel2.Controls.Add(this.textBox18);
			this.panel2.Controls.Add(this.textBox40);
			this.panel2.Controls.Add(this.textBox12);
			this.panel2.Controls.Add(this.textBox71);
			this.panel2.Controls.Add(this.textBox65);
			this.panel2.Controls.Add(this.textBox39);
			this.panel2.Controls.Add(this.textBox6);
			this.panel2.Controls.Add(this.textBox38);
			this.panel2.Controls.Add(this.textBox29);
			this.panel2.Controls.Add(this.textBox37);
			this.panel2.Controls.Add(this.textBox23);
			this.panel2.Controls.Add(this.textBox36);
			this.panel2.Controls.Add(this.textBox17);
			this.panel2.Controls.Add(this.textBox35);
			this.panel2.Controls.Add(this.textBox11);
			this.panel2.Controls.Add(this.textBox5);
			this.panel2.Controls.Add(this.balance);
			this.panel2.Controls.Add(this.reson2);
			this.panel2.Controls.Add(this.reson1);
			this.panel2.Controls.Add(this.cost);
			this.panel2.Controls.Add(this.slno);
			this.panel2.Controls.Add(this.income);
			this.panel2.Location = new System.Drawing.Point(267, 42);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(1320, 685);
			this.panel2.TabIndex = 14;
			this.panel2.Visible = false;
			// 
			// label9
			// 
			this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.label9.Location = new System.Drawing.Point(1077, 637);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(217, 44);
			this.label9.TabIndex = 10;
			this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label8
			// 
			this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.label8.Location = new System.Drawing.Point(600, 637);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(146, 44);
			this.label8.TabIndex = 9;
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label2
			// 
			this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.label2.Location = new System.Drawing.Point(109, 637);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(146, 44);
			this.label2.TabIndex = 8;
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// textBox76
			// 
			this.textBox76.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox76.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox76.Location = new System.Drawing.Point(1077, 592);
			this.textBox76.Name = "textBox76";
			this.textBox76.ReadOnly = true;
			this.textBox76.Size = new System.Drawing.Size(217, 26);
			this.textBox76.TabIndex = 7;
			this.textBox76.Text = "0";
			this.textBox76.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox76.Visible = false;
			this.textBox76.TextChanged += new System.EventHandler(this.TextBox10TextChanged);
			// 
			// textBox70
			// 
			this.textBox70.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox70.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox70.Location = new System.Drawing.Point(1077, 546);
			this.textBox70.Name = "textBox70";
			this.textBox70.ReadOnly = true;
			this.textBox70.Size = new System.Drawing.Size(217, 26);
			this.textBox70.TabIndex = 7;
			this.textBox70.Text = "0";
			this.textBox70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox70.Visible = false;
			this.textBox70.TextChanged += new System.EventHandler(this.TextBox10TextChanged);
			// 
			// textBox64
			// 
			this.textBox64.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox64.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox64.Location = new System.Drawing.Point(1077, 500);
			this.textBox64.Name = "textBox64";
			this.textBox64.ReadOnly = true;
			this.textBox64.Size = new System.Drawing.Size(217, 26);
			this.textBox64.TabIndex = 7;
			this.textBox64.Text = "0";
			this.textBox64.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox64.Visible = false;
			this.textBox64.TextChanged += new System.EventHandler(this.TextBox10TextChanged);
			// 
			// textBox34
			// 
			this.textBox34.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox34.Location = new System.Drawing.Point(1077, 269);
			this.textBox34.Name = "textBox34";
			this.textBox34.ReadOnly = true;
			this.textBox34.Size = new System.Drawing.Size(217, 26);
			this.textBox34.TabIndex = 7;
			this.textBox34.Text = "0";
			this.textBox34.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox34.Visible = false;
			this.textBox34.TextChanged += new System.EventHandler(this.TextBox10TextChanged);
			// 
			// textBox63
			// 
			this.textBox63.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox63.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox63.Location = new System.Drawing.Point(1077, 454);
			this.textBox63.Name = "textBox63";
			this.textBox63.ReadOnly = true;
			this.textBox63.Size = new System.Drawing.Size(217, 26);
			this.textBox63.TabIndex = 7;
			this.textBox63.Text = "0";
			this.textBox63.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox63.Visible = false;
			this.textBox63.TextChanged += new System.EventHandler(this.TextBox10TextChanged);
			// 
			// textBox28
			// 
			this.textBox28.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox28.Location = new System.Drawing.Point(1077, 223);
			this.textBox28.Name = "textBox28";
			this.textBox28.ReadOnly = true;
			this.textBox28.Size = new System.Drawing.Size(217, 26);
			this.textBox28.TabIndex = 7;
			this.textBox28.Text = "0";
			this.textBox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox28.Visible = false;
			this.textBox28.TextChanged += new System.EventHandler(this.TextBox10TextChanged);
			// 
			// textBox62
			// 
			this.textBox62.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox62.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox62.Location = new System.Drawing.Point(1077, 406);
			this.textBox62.Name = "textBox62";
			this.textBox62.ReadOnly = true;
			this.textBox62.Size = new System.Drawing.Size(217, 26);
			this.textBox62.TabIndex = 7;
			this.textBox62.Text = "0";
			this.textBox62.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox62.Visible = false;
			this.textBox62.TextChanged += new System.EventHandler(this.TextBox10TextChanged);
			// 
			// textBox22
			// 
			this.textBox22.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox22.Location = new System.Drawing.Point(1077, 175);
			this.textBox22.Name = "textBox22";
			this.textBox22.ReadOnly = true;
			this.textBox22.Size = new System.Drawing.Size(217, 26);
			this.textBox22.TabIndex = 7;
			this.textBox22.Text = "0";
			this.textBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox22.Visible = false;
			this.textBox22.TextChanged += new System.EventHandler(this.TextBox10TextChanged);
			// 
			// textBox61
			// 
			this.textBox61.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox61.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox61.Location = new System.Drawing.Point(1077, 359);
			this.textBox61.Name = "textBox61";
			this.textBox61.ReadOnly = true;
			this.textBox61.Size = new System.Drawing.Size(217, 26);
			this.textBox61.TabIndex = 7;
			this.textBox61.Text = "0";
			this.textBox61.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox61.Visible = false;
			this.textBox61.TextChanged += new System.EventHandler(this.TextBox10TextChanged);
			// 
			// textBox16
			// 
			this.textBox16.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox16.Location = new System.Drawing.Point(1077, 128);
			this.textBox16.Name = "textBox16";
			this.textBox16.ReadOnly = true;
			this.textBox16.Size = new System.Drawing.Size(217, 26);
			this.textBox16.TabIndex = 7;
			this.textBox16.Text = "0";
			this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox16.Visible = false;
			this.textBox16.TextChanged += new System.EventHandler(this.TextBox10TextChanged);
			// 
			// textBox60
			// 
			this.textBox60.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox60.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox60.Location = new System.Drawing.Point(1077, 314);
			this.textBox60.Name = "textBox60";
			this.textBox60.ReadOnly = true;
			this.textBox60.Size = new System.Drawing.Size(217, 26);
			this.textBox60.TabIndex = 7;
			this.textBox60.Text = "0";
			this.textBox60.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox60.Visible = false;
			this.textBox60.TextChanged += new System.EventHandler(this.TextBox10TextChanged);
			// 
			// textBox10
			// 
			this.textBox10.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox10.Location = new System.Drawing.Point(1077, 83);
			this.textBox10.Name = "textBox10";
			this.textBox10.ReadOnly = true;
			this.textBox10.Size = new System.Drawing.Size(217, 26);
			this.textBox10.TabIndex = 7;
			this.textBox10.Text = "0";
			this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox10.TextChanged += new System.EventHandler(this.TextBox10TextChanged);
			// 
			// textBox75
			// 
			this.textBox75.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox75.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox75.Location = new System.Drawing.Point(765, 592);
			this.textBox75.Name = "textBox75";
			this.textBox75.Size = new System.Drawing.Size(292, 26);
			this.textBox75.TabIndex = 6;
			this.textBox75.Visible = false;
			// 
			// textBox69
			// 
			this.textBox69.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox69.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox69.Location = new System.Drawing.Point(765, 546);
			this.textBox69.Name = "textBox69";
			this.textBox69.Size = new System.Drawing.Size(292, 26);
			this.textBox69.TabIndex = 6;
			this.textBox69.Visible = false;
			// 
			// textBox59
			// 
			this.textBox59.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox59.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox59.Location = new System.Drawing.Point(765, 500);
			this.textBox59.Name = "textBox59";
			this.textBox59.Size = new System.Drawing.Size(292, 26);
			this.textBox59.TabIndex = 6;
			this.textBox59.Visible = false;
			// 
			// textBox33
			// 
			this.textBox33.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox33.Location = new System.Drawing.Point(765, 269);
			this.textBox33.Name = "textBox33";
			this.textBox33.Size = new System.Drawing.Size(292, 26);
			this.textBox33.TabIndex = 6;
			this.textBox33.Visible = false;
			// 
			// textBox58
			// 
			this.textBox58.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox58.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox58.Location = new System.Drawing.Point(765, 454);
			this.textBox58.Name = "textBox58";
			this.textBox58.Size = new System.Drawing.Size(292, 26);
			this.textBox58.TabIndex = 6;
			this.textBox58.Visible = false;
			// 
			// textBox27
			// 
			this.textBox27.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox27.Location = new System.Drawing.Point(765, 223);
			this.textBox27.Name = "textBox27";
			this.textBox27.Size = new System.Drawing.Size(292, 26);
			this.textBox27.TabIndex = 6;
			this.textBox27.Visible = false;
			// 
			// textBox57
			// 
			this.textBox57.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox57.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox57.Location = new System.Drawing.Point(765, 406);
			this.textBox57.Name = "textBox57";
			this.textBox57.Size = new System.Drawing.Size(292, 26);
			this.textBox57.TabIndex = 6;
			this.textBox57.Visible = false;
			// 
			// textBox21
			// 
			this.textBox21.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox21.Location = new System.Drawing.Point(765, 175);
			this.textBox21.Name = "textBox21";
			this.textBox21.Size = new System.Drawing.Size(292, 26);
			this.textBox21.TabIndex = 6;
			this.textBox21.Visible = false;
			// 
			// textBox56
			// 
			this.textBox56.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox56.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox56.Location = new System.Drawing.Point(765, 359);
			this.textBox56.Name = "textBox56";
			this.textBox56.Size = new System.Drawing.Size(292, 26);
			this.textBox56.TabIndex = 6;
			this.textBox56.Visible = false;
			// 
			// textBox15
			// 
			this.textBox15.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox15.Location = new System.Drawing.Point(765, 128);
			this.textBox15.Name = "textBox15";
			this.textBox15.Size = new System.Drawing.Size(292, 26);
			this.textBox15.TabIndex = 6;
			this.textBox15.Visible = false;
			// 
			// textBox55
			// 
			this.textBox55.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox55.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox55.Location = new System.Drawing.Point(765, 314);
			this.textBox55.Name = "textBox55";
			this.textBox55.Size = new System.Drawing.Size(292, 26);
			this.textBox55.TabIndex = 6;
			this.textBox55.Visible = false;
			// 
			// textBox9
			// 
			this.textBox9.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox9.Location = new System.Drawing.Point(765, 83);
			this.textBox9.Name = "textBox9";
			this.textBox9.Size = new System.Drawing.Size(292, 26);
			this.textBox9.TabIndex = 6;
			// 
			// textBox74
			// 
			this.textBox74.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox74.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox74.Location = new System.Drawing.Point(596, 592);
			this.textBox74.Name = "textBox74";
			this.textBox74.Size = new System.Drawing.Size(148, 26);
			this.textBox74.TabIndex = 5;
			this.textBox74.Text = "0";
			this.textBox74.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox74.Visible = false;
			this.textBox74.TextChanged += new System.EventHandler(this.TextBox72TextChanged);
			// 
			// textBox68
			// 
			this.textBox68.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox68.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox68.Location = new System.Drawing.Point(596, 546);
			this.textBox68.Name = "textBox68";
			this.textBox68.Size = new System.Drawing.Size(148, 26);
			this.textBox68.TabIndex = 5;
			this.textBox68.Text = "0";
			this.textBox68.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox68.Visible = false;
			this.textBox68.TextChanged += new System.EventHandler(this.TextBox66TextChanged);
			// 
			// textBox54
			// 
			this.textBox54.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox54.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox54.Location = new System.Drawing.Point(596, 500);
			this.textBox54.Name = "textBox54";
			this.textBox54.Size = new System.Drawing.Size(148, 26);
			this.textBox54.TabIndex = 5;
			this.textBox54.Text = "0";
			this.textBox54.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox54.Visible = false;
			this.textBox54.TextChanged += new System.EventHandler(this.TextBox44TextChanged);
			// 
			// textBox32
			// 
			this.textBox32.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox32.Location = new System.Drawing.Point(596, 269);
			this.textBox32.Name = "textBox32";
			this.textBox32.Size = new System.Drawing.Size(148, 26);
			this.textBox32.TabIndex = 5;
			this.textBox32.Text = "0";
			this.textBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox32.Visible = false;
			this.textBox32.TextChanged += new System.EventHandler(this.TextBox30TextChanged);
			// 
			// textBox53
			// 
			this.textBox53.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox53.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox53.Location = new System.Drawing.Point(596, 454);
			this.textBox53.Name = "textBox53";
			this.textBox53.Size = new System.Drawing.Size(148, 26);
			this.textBox53.TabIndex = 5;
			this.textBox53.Text = "0";
			this.textBox53.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox53.Visible = false;
			this.textBox53.TextChanged += new System.EventHandler(this.TextBox43TextChanged);
			// 
			// textBox26
			// 
			this.textBox26.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox26.Location = new System.Drawing.Point(596, 223);
			this.textBox26.Name = "textBox26";
			this.textBox26.Size = new System.Drawing.Size(148, 26);
			this.textBox26.TabIndex = 5;
			this.textBox26.Text = "0";
			this.textBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox26.Visible = false;
			this.textBox26.TextChanged += new System.EventHandler(this.TextBox24TextChanged);
			// 
			// textBox52
			// 
			this.textBox52.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox52.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox52.Location = new System.Drawing.Point(596, 406);
			this.textBox52.Name = "textBox52";
			this.textBox52.Size = new System.Drawing.Size(148, 26);
			this.textBox52.TabIndex = 5;
			this.textBox52.Text = "0";
			this.textBox52.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox52.Visible = false;
			this.textBox52.TextChanged += new System.EventHandler(this.TextBox42TextChanged);
			// 
			// textBox20
			// 
			this.textBox20.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox20.Location = new System.Drawing.Point(596, 175);
			this.textBox20.Name = "textBox20";
			this.textBox20.Size = new System.Drawing.Size(148, 26);
			this.textBox20.TabIndex = 5;
			this.textBox20.Text = "0";
			this.textBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox20.Visible = false;
			this.textBox20.TextChanged += new System.EventHandler(this.TextBox18TextChanged);
			// 
			// textBox51
			// 
			this.textBox51.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox51.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox51.Location = new System.Drawing.Point(596, 359);
			this.textBox51.Name = "textBox51";
			this.textBox51.Size = new System.Drawing.Size(148, 26);
			this.textBox51.TabIndex = 5;
			this.textBox51.Text = "0";
			this.textBox51.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox51.Visible = false;
			this.textBox51.TextChanged += new System.EventHandler(this.TextBox41TextChanged);
			// 
			// textBox14
			// 
			this.textBox14.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox14.Location = new System.Drawing.Point(596, 128);
			this.textBox14.Name = "textBox14";
			this.textBox14.Size = new System.Drawing.Size(148, 26);
			this.textBox14.TabIndex = 5;
			this.textBox14.Text = "0";
			this.textBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox14.Visible = false;
			this.textBox14.TextChanged += new System.EventHandler(this.TextBox12TextChanged);
			// 
			// textBox50
			// 
			this.textBox50.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox50.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox50.Location = new System.Drawing.Point(596, 314);
			this.textBox50.Name = "textBox50";
			this.textBox50.Size = new System.Drawing.Size(148, 26);
			this.textBox50.TabIndex = 5;
			this.textBox50.Text = "0";
			this.textBox50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox50.Visible = false;
			this.textBox50.TextChanged += new System.EventHandler(this.TextBox40TextChanged);
			// 
			// textBox8
			// 
			this.textBox8.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox8.Location = new System.Drawing.Point(596, 83);
			this.textBox8.Name = "textBox8";
			this.textBox8.Size = new System.Drawing.Size(148, 26);
			this.textBox8.TabIndex = 5;
			this.textBox8.Text = "0";
			this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox8.TextChanged += new System.EventHandler(this.TextBox6TextChanged);
			// 
			// textBox73
			// 
			this.textBox73.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox73.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox73.Location = new System.Drawing.Point(281, 593);
			this.textBox73.Name = "textBox73";
			this.textBox73.Size = new System.Drawing.Size(262, 26);
			this.textBox73.TabIndex = 4;
			this.textBox73.Visible = false;
			// 
			// textBox67
			// 
			this.textBox67.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox67.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox67.Location = new System.Drawing.Point(281, 546);
			this.textBox67.Name = "textBox67";
			this.textBox67.Size = new System.Drawing.Size(262, 26);
			this.textBox67.TabIndex = 4;
			this.textBox67.Visible = false;
			// 
			// textBox49
			// 
			this.textBox49.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox49.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox49.Location = new System.Drawing.Point(281, 500);
			this.textBox49.Name = "textBox49";
			this.textBox49.Size = new System.Drawing.Size(262, 26);
			this.textBox49.TabIndex = 4;
			this.textBox49.Visible = false;
			// 
			// textBox31
			// 
			this.textBox31.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox31.Location = new System.Drawing.Point(281, 269);
			this.textBox31.Name = "textBox31";
			this.textBox31.Size = new System.Drawing.Size(262, 26);
			this.textBox31.TabIndex = 4;
			this.textBox31.Visible = false;
			// 
			// textBox48
			// 
			this.textBox48.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox48.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox48.Location = new System.Drawing.Point(281, 454);
			this.textBox48.Name = "textBox48";
			this.textBox48.Size = new System.Drawing.Size(262, 26);
			this.textBox48.TabIndex = 4;
			this.textBox48.Visible = false;
			// 
			// textBox25
			// 
			this.textBox25.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox25.Location = new System.Drawing.Point(281, 223);
			this.textBox25.Name = "textBox25";
			this.textBox25.Size = new System.Drawing.Size(262, 26);
			this.textBox25.TabIndex = 4;
			this.textBox25.Visible = false;
			// 
			// textBox47
			// 
			this.textBox47.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox47.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox47.Location = new System.Drawing.Point(281, 406);
			this.textBox47.Name = "textBox47";
			this.textBox47.Size = new System.Drawing.Size(262, 26);
			this.textBox47.TabIndex = 4;
			this.textBox47.Visible = false;
			// 
			// textBox19
			// 
			this.textBox19.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox19.Location = new System.Drawing.Point(281, 175);
			this.textBox19.Name = "textBox19";
			this.textBox19.Size = new System.Drawing.Size(262, 26);
			this.textBox19.TabIndex = 4;
			this.textBox19.Visible = false;
			// 
			// textBox46
			// 
			this.textBox46.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox46.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox46.Location = new System.Drawing.Point(281, 359);
			this.textBox46.Name = "textBox46";
			this.textBox46.Size = new System.Drawing.Size(262, 26);
			this.textBox46.TabIndex = 4;
			this.textBox46.Visible = false;
			// 
			// textBox13
			// 
			this.textBox13.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox13.Location = new System.Drawing.Point(281, 128);
			this.textBox13.Name = "textBox13";
			this.textBox13.Size = new System.Drawing.Size(262, 26);
			this.textBox13.TabIndex = 4;
			this.textBox13.Visible = false;
			// 
			// textBox45
			// 
			this.textBox45.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox45.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox45.Location = new System.Drawing.Point(281, 314);
			this.textBox45.Name = "textBox45";
			this.textBox45.Size = new System.Drawing.Size(262, 26);
			this.textBox45.TabIndex = 4;
			this.textBox45.Visible = false;
			// 
			// textBox7
			// 
			this.textBox7.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox7.Location = new System.Drawing.Point(281, 83);
			this.textBox7.Name = "textBox7";
			this.textBox7.Size = new System.Drawing.Size(262, 26);
			this.textBox7.TabIndex = 4;
			// 
			// textBox72
			// 
			this.textBox72.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox72.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox72.Location = new System.Drawing.Point(109, 593);
			this.textBox72.Name = "textBox72";
			this.textBox72.Size = new System.Drawing.Size(146, 26);
			this.textBox72.TabIndex = 3;
			this.textBox72.Text = "0";
			this.textBox72.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox72.Visible = false;
			this.textBox72.TextChanged += new System.EventHandler(this.TextBox72TextChanged);
			// 
			// textBox66
			// 
			this.textBox66.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox66.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox66.Location = new System.Drawing.Point(109, 547);
			this.textBox66.Name = "textBox66";
			this.textBox66.Size = new System.Drawing.Size(146, 26);
			this.textBox66.TabIndex = 3;
			this.textBox66.Text = "0";
			this.textBox66.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox66.Visible = false;
			this.textBox66.TextChanged += new System.EventHandler(this.TextBox66TextChanged);
			// 
			// textBox44
			// 
			this.textBox44.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox44.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox44.Location = new System.Drawing.Point(109, 501);
			this.textBox44.Name = "textBox44";
			this.textBox44.Size = new System.Drawing.Size(146, 26);
			this.textBox44.TabIndex = 3;
			this.textBox44.Text = "0";
			this.textBox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox44.Visible = false;
			this.textBox44.TextChanged += new System.EventHandler(this.TextBox44TextChanged);
			// 
			// textBox43
			// 
			this.textBox43.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox43.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox43.Location = new System.Drawing.Point(109, 455);
			this.textBox43.Name = "textBox43";
			this.textBox43.Size = new System.Drawing.Size(146, 26);
			this.textBox43.TabIndex = 3;
			this.textBox43.Text = "0";
			this.textBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox43.Visible = false;
			this.textBox43.TextChanged += new System.EventHandler(this.TextBox43TextChanged);
			// 
			// textBox30
			// 
			this.textBox30.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox30.Location = new System.Drawing.Point(109, 270);
			this.textBox30.Name = "textBox30";
			this.textBox30.Size = new System.Drawing.Size(146, 26);
			this.textBox30.TabIndex = 3;
			this.textBox30.Text = "0";
			this.textBox30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox30.Visible = false;
			this.textBox30.TextChanged += new System.EventHandler(this.TextBox30TextChanged);
			// 
			// textBox42
			// 
			this.textBox42.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox42.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox42.Location = new System.Drawing.Point(109, 407);
			this.textBox42.Name = "textBox42";
			this.textBox42.Size = new System.Drawing.Size(146, 26);
			this.textBox42.TabIndex = 3;
			this.textBox42.Text = "0";
			this.textBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox42.Visible = false;
			this.textBox42.TextChanged += new System.EventHandler(this.TextBox42TextChanged);
			// 
			// textBox24
			// 
			this.textBox24.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox24.Location = new System.Drawing.Point(109, 224);
			this.textBox24.Name = "textBox24";
			this.textBox24.Size = new System.Drawing.Size(146, 26);
			this.textBox24.TabIndex = 3;
			this.textBox24.Text = "0";
			this.textBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox24.Visible = false;
			this.textBox24.TextChanged += new System.EventHandler(this.TextBox24TextChanged);
			// 
			// textBox41
			// 
			this.textBox41.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox41.Location = new System.Drawing.Point(109, 360);
			this.textBox41.Name = "textBox41";
			this.textBox41.Size = new System.Drawing.Size(146, 26);
			this.textBox41.TabIndex = 3;
			this.textBox41.Text = "0";
			this.textBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox41.Visible = false;
			this.textBox41.TextChanged += new System.EventHandler(this.TextBox41TextChanged);
			// 
			// textBox18
			// 
			this.textBox18.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox18.Location = new System.Drawing.Point(109, 176);
			this.textBox18.Name = "textBox18";
			this.textBox18.Size = new System.Drawing.Size(146, 26);
			this.textBox18.TabIndex = 3;
			this.textBox18.Text = "0";
			this.textBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox18.Visible = false;
			this.textBox18.TextChanged += new System.EventHandler(this.TextBox18TextChanged);
			// 
			// textBox40
			// 
			this.textBox40.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox40.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox40.Location = new System.Drawing.Point(109, 315);
			this.textBox40.Name = "textBox40";
			this.textBox40.Size = new System.Drawing.Size(146, 26);
			this.textBox40.TabIndex = 3;
			this.textBox40.Text = "0";
			this.textBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox40.Visible = false;
			this.textBox40.TextChanged += new System.EventHandler(this.TextBox40TextChanged);
			// 
			// textBox12
			// 
			this.textBox12.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox12.Location = new System.Drawing.Point(109, 129);
			this.textBox12.Name = "textBox12";
			this.textBox12.Size = new System.Drawing.Size(146, 26);
			this.textBox12.TabIndex = 3;
			this.textBox12.Text = "0";
			this.textBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox12.Visible = false;
			this.textBox12.TextChanged += new System.EventHandler(this.TextBox12TextChanged);
			// 
			// textBox71
			// 
			this.textBox71.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox71.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox71.Location = new System.Drawing.Point(23, 592);
			this.textBox71.Name = "textBox71";
			this.textBox71.ReadOnly = true;
			this.textBox71.Size = new System.Drawing.Size(51, 26);
			this.textBox71.TabIndex = 2;
			this.textBox71.Text = "12";
			this.textBox71.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBox71.Visible = false;
			// 
			// textBox65
			// 
			this.textBox65.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox65.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox65.Location = new System.Drawing.Point(23, 546);
			this.textBox65.Name = "textBox65";
			this.textBox65.ReadOnly = true;
			this.textBox65.Size = new System.Drawing.Size(51, 26);
			this.textBox65.TabIndex = 2;
			this.textBox65.Text = "11";
			this.textBox65.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBox65.Visible = false;
			// 
			// textBox39
			// 
			this.textBox39.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox39.Location = new System.Drawing.Point(23, 500);
			this.textBox39.Name = "textBox39";
			this.textBox39.ReadOnly = true;
			this.textBox39.Size = new System.Drawing.Size(51, 26);
			this.textBox39.TabIndex = 2;
			this.textBox39.Text = "10";
			this.textBox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBox39.Visible = false;
			// 
			// textBox6
			// 
			this.textBox6.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox6.Location = new System.Drawing.Point(110, 84);
			this.textBox6.Name = "textBox6";
			this.textBox6.Size = new System.Drawing.Size(146, 26);
			this.textBox6.TabIndex = 3;
			this.textBox6.Text = "0";
			this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBox6.TextChanged += new System.EventHandler(this.TextBox6TextChanged);
			// 
			// textBox38
			// 
			this.textBox38.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox38.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox38.Location = new System.Drawing.Point(23, 454);
			this.textBox38.Name = "textBox38";
			this.textBox38.ReadOnly = true;
			this.textBox38.Size = new System.Drawing.Size(51, 26);
			this.textBox38.TabIndex = 2;
			this.textBox38.Text = "9";
			this.textBox38.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBox38.Visible = false;
			// 
			// textBox29
			// 
			this.textBox29.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox29.Location = new System.Drawing.Point(23, 269);
			this.textBox29.Name = "textBox29";
			this.textBox29.ReadOnly = true;
			this.textBox29.Size = new System.Drawing.Size(51, 26);
			this.textBox29.TabIndex = 2;
			this.textBox29.Text = "5";
			this.textBox29.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBox29.Visible = false;
			// 
			// textBox37
			// 
			this.textBox37.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox37.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox37.Location = new System.Drawing.Point(23, 406);
			this.textBox37.Name = "textBox37";
			this.textBox37.ReadOnly = true;
			this.textBox37.Size = new System.Drawing.Size(51, 26);
			this.textBox37.TabIndex = 2;
			this.textBox37.Text = "8";
			this.textBox37.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBox37.Visible = false;
			// 
			// textBox23
			// 
			this.textBox23.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox23.Location = new System.Drawing.Point(23, 223);
			this.textBox23.Name = "textBox23";
			this.textBox23.ReadOnly = true;
			this.textBox23.Size = new System.Drawing.Size(51, 26);
			this.textBox23.TabIndex = 2;
			this.textBox23.Text = "4";
			this.textBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBox23.Visible = false;
			// 
			// textBox36
			// 
			this.textBox36.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox36.Location = new System.Drawing.Point(23, 359);
			this.textBox36.Name = "textBox36";
			this.textBox36.ReadOnly = true;
			this.textBox36.Size = new System.Drawing.Size(51, 26);
			this.textBox36.TabIndex = 2;
			this.textBox36.Text = "7";
			this.textBox36.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBox36.Visible = false;
			// 
			// textBox17
			// 
			this.textBox17.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox17.Location = new System.Drawing.Point(23, 175);
			this.textBox17.Name = "textBox17";
			this.textBox17.ReadOnly = true;
			this.textBox17.Size = new System.Drawing.Size(51, 26);
			this.textBox17.TabIndex = 2;
			this.textBox17.Text = "3";
			this.textBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBox17.Visible = false;
			// 
			// textBox35
			// 
			this.textBox35.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox35.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox35.Location = new System.Drawing.Point(23, 314);
			this.textBox35.Name = "textBox35";
			this.textBox35.ReadOnly = true;
			this.textBox35.Size = new System.Drawing.Size(51, 26);
			this.textBox35.TabIndex = 2;
			this.textBox35.Text = "6";
			this.textBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBox35.Visible = false;
			// 
			// textBox11
			// 
			this.textBox11.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox11.Location = new System.Drawing.Point(23, 128);
			this.textBox11.Name = "textBox11";
			this.textBox11.ReadOnly = true;
			this.textBox11.Size = new System.Drawing.Size(51, 26);
			this.textBox11.TabIndex = 2;
			this.textBox11.Text = "2";
			this.textBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.textBox11.Visible = false;
			// 
			// textBox5
			// 
			this.textBox5.BackColor = System.Drawing.Color.AliceBlue;
			this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox5.Location = new System.Drawing.Point(23, 83);
			this.textBox5.Name = "textBox5";
			this.textBox5.ReadOnly = true;
			this.textBox5.Size = new System.Drawing.Size(51, 26);
			this.textBox5.TabIndex = 2;
			this.textBox5.Text = "1";
			this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// balance
			// 
			this.balance.BackColor = System.Drawing.Color.DeepSkyBlue;
			this.balance.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.balance.Location = new System.Drawing.Point(1077, 22);
			this.balance.Name = "balance";
			this.balance.Size = new System.Drawing.Size(217, 31);
			this.balance.TabIndex = 0;
			this.balance.Text = "Balance";
			this.balance.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// reson2
			// 
			this.reson2.BackColor = System.Drawing.Color.DeepSkyBlue;
			this.reson2.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.reson2.Location = new System.Drawing.Point(765, 23);
			this.reson2.Name = "reson2";
			this.reson2.Size = new System.Drawing.Size(292, 31);
			this.reson2.TabIndex = 0;
			this.reson2.Text = "Reason";
			this.reson2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// reson1
			// 
			this.reson1.BackColor = System.Drawing.Color.DeepSkyBlue;
			this.reson1.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.reson1.Location = new System.Drawing.Point(281, 22);
			this.reson1.Name = "reson1";
			this.reson1.Size = new System.Drawing.Size(262, 31);
			this.reson1.TabIndex = 0;
			this.reson1.Text = "Reson";
			this.reson1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// cost
			// 
			this.cost.BackColor = System.Drawing.Color.DeepSkyBlue;
			this.cost.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cost.Location = new System.Drawing.Point(595, 22);
			this.cost.Name = "cost";
			this.cost.Size = new System.Drawing.Size(149, 31);
			this.cost.TabIndex = 0;
			this.cost.Text = "cost";
			this.cost.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// slno
			// 
			this.slno.BackColor = System.Drawing.Color.DeepSkyBlue;
			this.slno.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.slno.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.slno.Location = new System.Drawing.Point(23, 22);
			this.slno.Name = "slno";
			this.slno.Size = new System.Drawing.Size(51, 31);
			this.slno.TabIndex = 0;
			this.slno.Text = "Sl.No";
			this.slno.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// income
			// 
			this.income.BackColor = System.Drawing.Color.DeepSkyBlue;
			this.income.Font = new System.Drawing.Font("Sitka Display", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.income.Location = new System.Drawing.Point(109, 23);
			this.income.Name = "income";
			this.income.Size = new System.Drawing.Size(148, 31);
			this.income.TabIndex = 0;
			this.income.Text = "Income";
			this.income.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.LightSeaGreen;
			this.panel3.Controls.Add(this.pictureBox12);
			this.panel3.Controls.Add(this.pictureBox11);
			this.panel3.Location = new System.Drawing.Point(258, 733);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(1429, 123);
			this.panel3.TabIndex = 15;
			this.panel3.Visible = false;
			// 
			// pictureBox12
			// 
			this.pictureBox12.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox12.BackgroundImage")));
			this.pictureBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.pictureBox12.Location = new System.Drawing.Point(1006, 12);
			this.pictureBox12.Name = "pictureBox12";
			this.pictureBox12.Size = new System.Drawing.Size(60, 65);
			this.pictureBox12.TabIndex = 1;
			this.pictureBox12.TabStop = false;
			this.pictureBox12.Click += new System.EventHandler(this.PictureBox12Click);
			// 
			// pictureBox11
			// 
			this.pictureBox11.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox11.BackgroundImage")));
			this.pictureBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.pictureBox11.Location = new System.Drawing.Point(288, 12);
			this.pictureBox11.Name = "pictureBox11";
			this.pictureBox11.Size = new System.Drawing.Size(60, 65);
			this.pictureBox11.TabIndex = 1;
			this.pictureBox11.TabStop = false;
			this.pictureBox11.Click += new System.EventHandler(this.PictureBox11Click);
			// 
			// scrreen
			// 
			this.scrreen.BackColor = System.Drawing.Color.White;
			this.scrreen.Controls.Add(this.label15);
			this.scrreen.Controls.Add(this.label16);
			this.scrreen.Controls.Add(this.label17);
			this.scrreen.Controls.Add(this.label14);
			this.scrreen.Controls.Add(this.label13);
			this.scrreen.Controls.Add(this.label12);
			this.scrreen.Controls.Add(this.label11);
			this.scrreen.Controls.Add(this.label10);
			this.scrreen.Controls.Add(this.pictureBox16);
			this.scrreen.Controls.Add(this.pictureBox14);
			this.scrreen.Controls.Add(this.pictureBox13);
			this.scrreen.Location = new System.Drawing.Point(22, 104);
			this.scrreen.Name = "scrreen";
			this.scrreen.Size = new System.Drawing.Size(218, 310);
			this.scrreen.TabIndex = 18;
			this.scrreen.Visible = false;
			// 
			// label15
			// 
			this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.label15.Font = new System.Drawing.Font("Bodoni MT", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label15.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.label15.Location = new System.Drawing.Point(32, 232);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(147, 17);
			this.label15.TabIndex = 3;
			this.label15.Text = "Total Cost";
			this.label15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// label16
			// 
			this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.label16.Font = new System.Drawing.Font("Bodoni MT", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label16.Location = new System.Drawing.Point(12, 123);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(191, 26);
			this.label16.TabIndex = 3;
			this.label16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// label17
			// 
			this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.label17.Font = new System.Drawing.Font("Bodoni MT", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label17.Location = new System.Drawing.Point(32, 155);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(147, 17);
			this.label17.TabIndex = 3;
			this.label17.Text = "Remaining Limit";
			this.label17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// label14
			// 
			this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.label14.Font = new System.Drawing.Font("Bodoni MT", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label14.Location = new System.Drawing.Point(32, 106);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(147, 17);
			this.label14.TabIndex = 3;
			this.label14.Text = "Daily Limit";
			this.label14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// label13
			// 
			this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
			this.label13.Font = new System.Drawing.Font("Bodoni MT", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label13.Location = new System.Drawing.Point(32, 11);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(147, 17);
			this.label13.TabIndex = 3;
			this.label13.Text = "Balance";
			this.label13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// label12
			// 
			this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
			this.label12.Location = new System.Drawing.Point(12, 175);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(191, 34);
			this.label12.TabIndex = 2;
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label11
			// 
			this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.label11.Location = new System.Drawing.Point(12, 252);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(191, 45);
			this.label11.TabIndex = 2;
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label10
			// 
			this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(153)))));
			this.label10.Location = new System.Drawing.Point(12, 34);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(191, 46);
			this.label10.TabIndex = 2;
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox16
			// 
			this.pictureBox16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox16.BackgroundImage")));
			this.pictureBox16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pictureBox16.Location = new System.Drawing.Point(6, 224);
			this.pictureBox16.Name = "pictureBox16";
			this.pictureBox16.Size = new System.Drawing.Size(204, 82);
			this.pictureBox16.TabIndex = 1;
			this.pictureBox16.TabStop = false;
			// 
			// pictureBox14
			// 
			this.pictureBox14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox14.BackgroundImage")));
			this.pictureBox14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pictureBox14.Location = new System.Drawing.Point(6, 6);
			this.pictureBox14.Name = "pictureBox14";
			this.pictureBox14.Size = new System.Drawing.Size(206, 87);
			this.pictureBox14.TabIndex = 0;
			this.pictureBox14.TabStop = false;
			// 
			// pictureBox13
			// 
			this.pictureBox13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox13.BackgroundImage")));
			this.pictureBox13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pictureBox13.Location = new System.Drawing.Point(4, 99);
			this.pictureBox13.Name = "pictureBox13";
			this.pictureBox13.Size = new System.Drawing.Size(206, 119);
			this.pictureBox13.TabIndex = 0;
			this.pictureBox13.TabStop = false;
			// 
			// monthCalendar1
			// 
			this.monthCalendar1.Location = new System.Drawing.Point(13, 522);
			this.monthCalendar1.Name = "monthCalendar1";
			this.monthCalendar1.TabIndex = 19;
			this.monthCalendar1.Visible = false;
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.LightSeaGreen;
			this.label1.Location = new System.Drawing.Point(0, 37);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(166, 819);
			this.label1.TabIndex = 1;
			// 
			// MainForm
			// 
			this.AllowDrop = true;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.AutoSize = true;
			this.BackColor = System.Drawing.Color.WhiteSmoke;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.ClientSize = new System.Drawing.Size(1584, 856);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.monthCalendar1);
			this.Controls.Add(this.scrreen);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.pictureBox10);
			this.Controls.Add(this.pictureBox7);
			this.Controls.Add(this.pictureBox9);
			this.Controls.Add(this.pictureBox8);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.pictureBox2);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.menuStrip1);
			this.Controls.Add(this.label1);
			this.Cursor = System.Windows.Forms.Cursors.Default;
			this.MainMenuStrip = this.menuStrip1;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Walet";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			this.panel3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
			this.scrreen.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.ToolStripMenuItem passwordChangeToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem limitChangeToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem sToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem showToolStripMenuItem;
		private System.Windows.Forms.MonthCalendar monthCalendar1;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.PictureBox pictureBox13;
		private System.Windows.Forms.PictureBox pictureBox14;
		private System.Windows.Forms.PictureBox pictureBox16;
		private System.Windows.Forms.Panel scrreen;
		private System.Windows.Forms.TextBox textBox5;
		private System.Windows.Forms.TextBox textBox11;
		private System.Windows.Forms.TextBox textBox35;
		private System.Windows.Forms.TextBox textBox17;
		private System.Windows.Forms.TextBox textBox36;
		private System.Windows.Forms.TextBox textBox23;
		private System.Windows.Forms.TextBox textBox37;
		private System.Windows.Forms.TextBox textBox29;
		private System.Windows.Forms.TextBox textBox38;
		private System.Windows.Forms.TextBox textBox6;
		private System.Windows.Forms.TextBox textBox39;
		private System.Windows.Forms.TextBox textBox65;
		private System.Windows.Forms.TextBox textBox71;
		private System.Windows.Forms.TextBox textBox12;
		private System.Windows.Forms.TextBox textBox40;
		private System.Windows.Forms.TextBox textBox18;
		private System.Windows.Forms.TextBox textBox41;
		private System.Windows.Forms.TextBox textBox24;
		private System.Windows.Forms.TextBox textBox42;
		private System.Windows.Forms.TextBox textBox30;
		private System.Windows.Forms.TextBox textBox43;
		private System.Windows.Forms.TextBox textBox44;
		private System.Windows.Forms.TextBox textBox66;
		private System.Windows.Forms.TextBox textBox72;
		private System.Windows.Forms.TextBox textBox7;
		private System.Windows.Forms.TextBox textBox45;
		private System.Windows.Forms.TextBox textBox13;
		private System.Windows.Forms.TextBox textBox46;
		private System.Windows.Forms.TextBox textBox19;
		private System.Windows.Forms.TextBox textBox47;
		private System.Windows.Forms.TextBox textBox25;
		private System.Windows.Forms.TextBox textBox48;
		private System.Windows.Forms.TextBox textBox31;
		private System.Windows.Forms.TextBox textBox49;
		private System.Windows.Forms.TextBox textBox67;
		private System.Windows.Forms.TextBox textBox73;
		private System.Windows.Forms.TextBox textBox8;
		private System.Windows.Forms.TextBox textBox50;
		private System.Windows.Forms.TextBox textBox14;
		private System.Windows.Forms.TextBox textBox51;
		private System.Windows.Forms.TextBox textBox20;
		private System.Windows.Forms.TextBox textBox52;
		private System.Windows.Forms.TextBox textBox26;
		private System.Windows.Forms.TextBox textBox53;
		private System.Windows.Forms.TextBox textBox32;
		private System.Windows.Forms.TextBox textBox54;
		private System.Windows.Forms.TextBox textBox68;
		private System.Windows.Forms.TextBox textBox74;
		private System.Windows.Forms.TextBox textBox9;
		private System.Windows.Forms.TextBox textBox55;
		private System.Windows.Forms.TextBox textBox15;
		private System.Windows.Forms.TextBox textBox56;
		private System.Windows.Forms.TextBox textBox21;
		private System.Windows.Forms.TextBox textBox57;
		private System.Windows.Forms.TextBox textBox27;
		private System.Windows.Forms.TextBox textBox58;
		private System.Windows.Forms.TextBox textBox33;
		private System.Windows.Forms.TextBox textBox59;
		private System.Windows.Forms.TextBox textBox69;
		private System.Windows.Forms.TextBox textBox75;
		private System.Windows.Forms.TextBox textBox10;
		private System.Windows.Forms.TextBox textBox60;
		private System.Windows.Forms.TextBox textBox16;
		private System.Windows.Forms.TextBox textBox61;
		private System.Windows.Forms.TextBox textBox22;
		private System.Windows.Forms.TextBox textBox62;
		private System.Windows.Forms.TextBox textBox28;
		private System.Windows.Forms.TextBox textBox63;
		private System.Windows.Forms.TextBox textBox34;
		private System.Windows.Forms.TextBox textBox64;
		private System.Windows.Forms.TextBox textBox70;
		private System.Windows.Forms.TextBox textBox76;
		private System.Windows.Forms.PictureBox pictureBox11;
		private System.Windows.Forms.PictureBox pictureBox12;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Label income;
		private System.Windows.Forms.Label slno;
		private System.Windows.Forms.Label cost;
		private System.Windows.Forms.Label reson1;
		private System.Windows.Forms.Label reson2;
		private System.Windows.Forms.Label balance;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.PictureBox pictureBox10;
		private System.Windows.Forms.PictureBox pictureBox9;
		private System.Windows.Forms.PictureBox pictureBox8;
		private System.Windows.Forms.PictureBox pictureBox7;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.PictureBox pictureBox6;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.PictureBox pictureBox5;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.TrackBar trackBar1;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.PictureBox pictureBox4;
		private System.Windows.Forms.PictureBox pictureBox3;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.ToolStripMenuItem suggestionToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem reportAbuseToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem supportToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem userGuideToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem rateUsToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem developerToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem waletToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem calenderToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem barChartToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem pieChartToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem stastisticsToolStripMenuItem;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
		private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
		private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
		private System.Windows.Forms.MenuStrip menuStrip1;
	}
}
